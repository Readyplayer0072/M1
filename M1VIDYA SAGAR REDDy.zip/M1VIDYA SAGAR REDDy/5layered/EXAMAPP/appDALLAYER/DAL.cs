﻿using appENTITY;
using appEXCEPTION;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace appDALLAYER
{
    public class DAL
    {
        static List<ENTITY> dlist = new List<ENTITY>();
        public bool ADDDEALERDAL(ENTITY newdealer)
        {
            bool isProductadded = false;
            try
            {
                dlist.Add(newdealer);
                serializeDAL();
                isProductadded = true;
            }
            catch(dealerEXCEPTION)
            {
                throw  ;
            }
            return isProductadded;
        }
        public static void serializeDAL()
        {
            FileStream fileStream = null;
            try
            {
                fileStream = new FileStream("dlist.ser", FileMode.Create, FileAccess.Write);
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(fileStream, dlist);
            }
            catch(IOException)
            {
                throw;
            }
            catch(Exception)
            {
                throw;

            }
            finally
            {
                fileStream.Close();
            }
          
        }
        public List<ENTITY> DISPLAYDEALERDAL()
        {
            return DeserializeDealerDAL();
        }
        public static List<ENTITY> DeserializeDealerDAL()
        {
            List<ENTITY> deserializedData = null;
            FileStream fileStream = null;
            try
            {
                fileStream = new FileStream("dList.ser", FileMode.Open, FileAccess.Read);
                BinaryFormatter Formatter = new BinaryFormatter();
                deserializedData = (List<ENTITY>)Formatter.Deserialize(fileStream);
            }
            catch (IOException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                fileStream.Close();
            }
            return deserializedData;
        }
        public ENTITY SearchDealerDAL(int id)
        {
            ENTITY searchedaircraft;
            try
            {
                searchedaircraft = dlist.Find(ENTITY => ENTITY.id == id);
            }
            catch (dealerEXCEPTION)
            {
                throw;
            }
            return searchedaircraft;
        }
    }
}
