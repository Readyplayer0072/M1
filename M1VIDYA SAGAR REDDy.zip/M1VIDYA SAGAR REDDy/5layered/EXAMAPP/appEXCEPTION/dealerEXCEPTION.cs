﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace appEXCEPTION
{
    public class dealerEXCEPTION : ApplicationException
    {
        public dealerEXCEPTION() : base() { }
       
        public dealerEXCEPTION(string message) : base(message) { }
    }
}                    