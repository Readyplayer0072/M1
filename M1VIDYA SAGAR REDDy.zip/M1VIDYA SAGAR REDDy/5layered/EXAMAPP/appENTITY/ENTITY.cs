﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace appENTITY
{[Serializable]
    public class ENTITY
    {
        public int id { get; set; }
        public string delid { get; set; }
        public string name { get; set; }
        public string pnumber { get; set; }
        public string status { get; set; }
        public string category { get; set; }
        public string  mailid { get; set; }
        public string vnumber { get; set; }
       // public DateTime sdate { get; set; }

    }
        
            
    
      
}    

