﻿using appBUSINESS;
using appENTITY;
using appEXCEPTION;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace appPLL
{
    class PRESENTATION
    {
        static void Main(string[] args)
        {
            int choice;
            do
            {
                Menu();

                bool chkid;
                chkid = int.TryParse(Console.ReadLine(), out choice);
                if (!chkid) { Console.WriteLine("enter valid entry"); }
                switch (choice)
                {
                    case 1:
                        ADDDEALER();
                        break;
                    case 2:DISPLAYDEALER();
                       break;
                    case 3:
                        SearchAircraftPL();
                       break;
                    default:
                        Console.WriteLine("invalid choice");
                        break;
                }
            } while (choice != 0);
        }
        public static void Menu()
        {
            Console.WriteLine("-------------------------------------------------------------------------");
            Console.WriteLine("Dealer management system (SMS)");
            Console.WriteLine("press 1 to add new dealer details");
            Console.WriteLine("press 2 to display Product details");
            Console.WriteLine("press 3 to search student details");
            Console.WriteLine("press 0 to exit");
            Console.WriteLine("-------------------------------------------------------------------------");
        }

        public static void ADDDEALER()
        {
            ENTITY objentity = new ENTITY();
            try
            {
                Console.WriteLine("Enter id");
              objentity.id = int.Parse(Console.ReadLine());
               
                Console.WriteLine("Enter dealer id");
                string delid = Console.ReadLine();
                if(delid.Length==6)
                {
                    if(delid[0]=='D'&& delid[1]=='L')
                    {
                        objentity.delid = delid;
                    }
                    else
                    {
                        throw new dealerEXCEPTION("invalid entry");
                    }
                       
                }
                else
                {
                    throw new dealerEXCEPTION("invalid entry 2");
                }
                
                Console.WriteLine("Enter name");
                objentity.name = Console.ReadLine();
                Console.WriteLine("Enter phone number");
                string pnumber = Console.ReadLine();
                if(pnumber.Length==10)
                {
                    if(pnumber[0]=='7' || pnumber[0] == '8'|| pnumber[0] == '9')
                    {
                        objentity.pnumber = pnumber;
                    }
                    else
                    {
                        throw new dealerEXCEPTION("invaid phone number .Enter valid number");
                    }

                }
                Console.WriteLine("Enter status");
                string status = Console.ReadLine();
                if(status=="Active"||status=="Inactive")
                {
                    objentity.status = status;
                }
                else
                {
                    throw new dealerEXCEPTION("invalid status .Enter either active or inactivee");
                }
                Console.WriteLine("Enter dealer category");
                string category = Console.ReadLine();
                if(category=="fruits" || category=="vegetables" || category=="Bakery" || category=="meat")
                {
                    objentity.category = category;
                }
                else
                {
                    throw new dealerEXCEPTION("invalid category.Enter any of the abov ones");
                }
                Console.WriteLine("Enter mailid");
               string mailid = Console.ReadLine();
                if (char.IsLetter(mailid[0]))
                {
                    if (mailid.Contains("@gmail.com") || mailid.Contains("@yahoo.com"))
                    {
                        objentity.mailid = mailid;
                    }

                    else
                    {
                        throw new dealerEXCEPTION("enter vaid email id");
                    }
                }
                else
                {
                    throw new dealerEXCEPTION("enter vaid email id");
                }
                Console.WriteLine("Enter dealer special number");
                string vnumber= Console.ReadLine();
                if(char.IsUpper(vnumber[0]) && char.IsUpper(vnumber[1]) && char.IsUpper(vnumber[2]) && char.IsUpper(vnumber[3]))
                {
                    if(vnumber[4]=='-')
                    {
                        objentity.vnumber = vnumber;
                    }
                    else
                    {
                        throw new dealerEXCEPTION("enter valid voucher ");
                    }
                }
                else
                {
                    throw new dealerEXCEPTION("enter valid voucher ");
                }

                
                BUSINESS objBUS = new BUSINESS();
                if(objBUS.ADDDEALERBLL(objentity)==false)
                {
                    throw new dealerEXCEPTION(" product record not found");
                }
                else
                {
                    Console.WriteLine(" product details added successfully");
                }




            }
            catch(dealerEXCEPTION Exception)
            {
                Console.WriteLine("error occured" + Exception.Message);
            }

        }
        public static void DISPLAYDEALER()
        {
            try
            {
                BUSINESS bllobj = new BUSINESS();
                List<ENTITY> sList = new List<ENTITY>();
                sList = bllobj.DISPLAYDEALERBLL();
                Console.WriteLine("dealer Details");
                Console.WriteLine("*************************************");
                foreach (ENTITY s in sList)
                {
                    Console.WriteLine("Aircraft Id:{0}\nAircraft delid:{1}\nAircraft name:{2}\nAircraft vnum:{7}\npnumber:{3}\nManufactured status:{4}\nMaintenance category:{5}\nMaintenance mailid:{6}\n ", s.id, s.delid, s.name, s.pnumber, s.status, s.category, s.mailid, s.vnumber);
                }
            }
            catch (dealerEXCEPTION e)
            {
                Console.WriteLine(e.Message);
            }
        }
        private static void SearchAircraftPL()
        {
            ENTITY searchedaircraft = null;
            try
            {
                Console.WriteLine("Enter id to be searched");
                int id =int.Parse( Console.ReadLine());
                BUSINESS DEALERBLL = new BUSINESS();
                searchedaircraft = DEALERBLL.SearchDealerBLL(id);
                if (searchedaircraft != null)
                {
                    Console.WriteLine("Searched Aircraft Details:");
                    Console.WriteLine("Aircraft ID:{0}", searchedaircraft.id);
                    Console.WriteLine("Aircraft Typdelide:{0}", searchedaircraft.delid);
                    Console.WriteLine("Aircraft ame:{0}", searchedaircraft.name);
                    Console.WriteLine("Aircraft pnumber:{0}", searchedaircraft.pnumber);
                    Console.WriteLine("Manufacturer status:{0}", searchedaircraft.status);
                    Console.WriteLine("Manufactured category:{0}", searchedaircraft.category);
                    Console.WriteLine("Manufactured mailid:{0}", searchedaircraft.mailid);
                    Console.WriteLine("Manufactured vnumber:{0}", searchedaircraft.vnumber);
                }
            }
            catch (dealerEXCEPTION exception)
            {
                Console.WriteLine(exception.Message);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception.Message);
            }
        }
    }
}
       