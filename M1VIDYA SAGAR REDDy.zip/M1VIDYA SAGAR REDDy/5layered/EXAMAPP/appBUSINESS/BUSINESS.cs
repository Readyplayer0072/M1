﻿using appDALLAYER;
using appENTITY;
using appEXCEPTION;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace appBUSINESS
{
    public class BUSINESS
    {

        List<ENTITY> sList = new List<ENTITY>();
        public bool ADDDEALERBLL(ENTITY dealer)
        {
            bool isAdded = false;
            try
            {
                DAL operations = new DAL();
                if (validatedealer(dealer))
                {
                    isAdded = operations.ADDDEALERDAL(dealer);
                    Console.WriteLine("valid detail are given");
                }
                else
                {
                    throw new dealerEXCEPTION("validation failed!product details cannot be added");
                }
                if (isAdded == false)
                {
                    throw new dealerEXCEPTION("product details not added");
                }




            }
            catch (dealerEXCEPTION D1)
            {
                throw D1;

            }
            return isAdded;


        }

        private static bool validatedealer(ENTITY dealer)
        {
            bool isvalid = true;

            StringBuilder message = new StringBuilder();
            if (dealer.name == null || dealer.name == string.Empty)
            {
                message.Append(Environment.NewLine + "name can not be blank ");
                isvalid = false;
            }

            if (isvalid == false)
            {
                throw new dealerEXCEPTION(message.ToString());
            }
            return isvalid;
        }
        public List<ENTITY> DISPLAYDEALERBLL()
        {
           DAL dealeroperations = new DAL();
            sList = dealeroperations.DISPLAYDEALERDAL();
            try
            {
               
                if (sList.Count <= 0)
                {
                    throw new dealerEXCEPTION("No records found");
                }
            }
            catch (dealerEXCEPTION e)
            {
                throw e;
            }
            return sList;
        }
        public ENTITY SearchDealerBLL(int id)
        {
            ENTITY searchedaircraft = null;
            try
            {
                DAL DEALERDAL = new DAL();
                searchedaircraft = DEALERDAL.SearchDealerDAL(id);
                if (searchedaircraft == null)
                {
                    throw new dealerEXCEPTION("Aircraft details not found");
                }
            }
            catch (dealerEXCEPTION exception)
            {
                throw exception;
            }
            return searchedaircraft;
        }


    }
}

