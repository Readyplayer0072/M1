﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMSException
{
    /// <summary>
    /// exception class to catch the exceptions occuring in student management system
    /// Author:vidya sagar
    /// DOC:3rd OCT 2018
    /// </summary>
    public class studentexception : ApplicationException
    {
        //default Constructor ,that inherits the  base constructor
        public studentexception() :base()
        {

        }
        //parameterized constructor for passing thr error/exception message
        public studentexception(string message):base(message)
        {

        }

    }
}
