﻿using SMSDAL;
using SMSEntity;
using SMSException;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMStBLL
{/// <summary>
 /// TO CReate Validation mehod and to invoke the operation from DAL
 /// Author:vidya sagar
 /// DOC:3rd OCT 2018
 /// </summary>
    public class studentBLL
    {
        static List<student> slist = new List<student>();
        public bool AddStudentBL(student student)
        {
            bool isAdeed = false;
            try
            {
                studentDAL studentOperations = new studentDAL();
                if (ValidateStudent(student))
                {
                    isAdeed = studentOperations.AddStudentDAL(student);
                }
                else
                {
                    throw new studentexception("valiationfailed!!student details");
                }
                if (isAdeed == false)
                {
                    throw new studentexception("student details not addded"); }
            }
            catch (studentexception e)
            {
                throw e;
            }
            return isAdeed;
        }

        private static bool ValidateStudent(student student)
        {
            bool validstudent = true;
            StringBuilder message = new StringBuilder();
            if (student.Rollnumber <= 0 || student.Rollnumber > 60)
            {
                message.Append(Environment.NewLine + "Invalid RollNumber");
                validstudent = false;
            }
            if (student.Name == null || student.Name == string.Empty)
            {
                message.Append(Environment.NewLine + "name cannot be blank");
                validstudent = false;
            }
            if (validstudent == false)
            {
                throw new studentexception(message.ToString());
            }
            return validstudent;
        }
        public List<student> DisplayStudentBL()
        {
            studentDAL studentOperations = new studentDAL();
            try
            {
                slist = studentOperations.DisplayStudentDAL();
                if(slist.Count<=0)
                {
                    throw new studentexception("NO REcords Found!!!");
                }
            }
            catch(studentexception e)
            {
                throw e;
            }
            return slist;
        }
        public student searchstudentBLL(int Rollnumber)
        {
            student searchedstudent = null;
            try
            {
                studentDAL studentDAL = new studentDAL();
                searchedstudent = studentDAL.searchedstudentDAL(Rollnumber);
                if (searchedstudent == null) throw new studentexception("student not found");
            }
            catch(studentexception Exception )
            {
                throw Exception;
            }
            return searchedstudent;
        }
        public student searchvoterBLL(string VoterId)
        {
            Voter searchedvoter = null;
            try
            {
                studentDAL studentDAL = new studentDAL();
                searchedstudent = studentDAL.searchedstudentDAL(Rollnumber);
                if (searchedstudent == null) throw new studentexception("student not found");
            }
            catch (studentexception Exception)
            {
                throw Exception;
            }
            return searchedstudent;
        }
}      
        


