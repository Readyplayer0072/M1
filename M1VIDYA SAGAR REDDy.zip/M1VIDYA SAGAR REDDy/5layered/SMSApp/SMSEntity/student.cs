﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMSEntity
{
    /// <summary>
/// To create the methods for performing operations on students entity
/// Author:vidya sagar
/// DOC:3rd OCT 2018
/// </summary>
    [Serializable]
    public class student
    {
        public int Rollnumber { get; set; }
        public string Name{ get; set; }
        public string department { get; set; }
        public  Grade Grade { get; set; }
    }
    /// <summary>
    /// Grade enumeration ,values can be A,B,C,D
    /// </summary>
    public enum Grade
    {
        A,B,C,D
    }
}
