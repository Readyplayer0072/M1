﻿using SMSEntity;
using SMSException;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace SMSDAL
{/// <summary>
 /// TO create the methods for operating  on student entity
 /// Author:vidya sagar
 /// DOC:3rd OCT 2018
 /// </summary>
    public class studentDAL
    {
        static List<student> studentlist = new List<student>();



        /// <summary>
        /// 
        /// </summary>
        public bool AddStudentDAL(student newstudent)
        {
            bool isStudentAdded = false;
            try
            {
                studentlist.Add(newstudent);
                SerializeStudentDAL();
                isStudentAdded = true;
            }
            catch (studentexception)
            {
                throw;
            }
            return isStudentAdded;


        } /// <summary>
          /// 
          /// </summary>
        public static void SerializeStudentDAL()
        {
            FileStream fstream = null;
            try
            {
                fstream = new FileStream("studentlist.ser", FileMode.Create, FileAccess.Write);
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(fstream, studentlist);

            }
            catch (IOException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                fstream.Close();
            }
        }

        /// <summary>
        /// Function for displaying the data from the student list
        /// </summary>
        /// <return>List of Students</return>
        public List<student> DisplayStudentDAL()

        {
            return DeserializeStudentDAL();
        }

        public static List<student> DeserializeStudentDAL()
        {
            List<student> deserializedData = null;
            FileStream fstream = null;
            try
            {
                fstream = new FileStream("studentlist.ser", FileMode.Open, FileAccess.Read);
                BinaryFormatter formatter = new BinaryFormatter();
                deserializedData = (List<student>)formatter.Deserialize(fstream);
            }
            catch (IOException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                fstream.Close();
            }
            return deserializedData;



        }

        public student searchedstudentDAL(int Rollnumber)
        {
            student searchedstudent;

            try
            {
                searchedstudent = studentlist.Find(student => student.Rollnumber == Rollnumber);
            }
            catch (studentexception) { throw; }
            return searchedstudent;
        }
        

        
    }
}
  



