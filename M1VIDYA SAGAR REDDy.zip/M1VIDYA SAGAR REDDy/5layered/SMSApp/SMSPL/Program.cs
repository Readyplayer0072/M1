﻿using SMSDAL;
using SMSEntity;
using SMSException;
using SMStBLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMSPL
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice;
            do
            {
                Printmenu();
                Console.WriteLine("enter your choice:");
                bool chkChoice;

                chkChoice = int.TryParse(Console.ReadLine(), out choice);
                if (!chkChoice) { Console.WriteLine("Invalid Input"); }
                switch (choice)
                {
                    case 1:
                        AddStudentPL();
                        break;
                    case 2:
                        DisplayStudentPL();
                        break;
                    case 3:
                       SearchedStudentPl();
                       break;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            } while (choice != 0);
            
            
        }
        public static void Printmenu()
        {
            Console.WriteLine("============================================================================");
            Console.WriteLine("Student Management System(SMS) ");
            Console.WriteLine("Press 1 To Add New Student ");
            Console.WriteLine("Press 2 To Display All the students ");
            Console.WriteLine("Press 3 To Search student  ");
            Console.WriteLine("Press 0 To Exit ");
            Console.WriteLine("============================================================================");

        }
        public static void AddStudentPL()
        {
            try
            {
                student objstudent = new student();
                Console.WriteLine("Enter the Student ID");
                bool chkid;
                int Rollnumber;
                //use TryParse to check if the enterd value is Parsebale or Not
                chkid = Int32.TryParse(Console.ReadLine(),out Rollnumber);
                //If the Parsing fails,throw the Exception
                if(chkid==false)
                {
                    throw new studentexception("Invalid Entry");
                }
                //If parsing is sucessful,store the studentId into the entity
                else
                {
                    objstudent.Rollnumber = Rollnumber;
                }
                Console.WriteLine("Enter Student Name:");
                objstudent.Name = Console.ReadLine();
                Console.WriteLine("Enter the Grade:");
                objstudent.Grade = (Grade)Enum.Parse(typeof(Grade), Console.ReadLine());

                studentBLL bllobj = new studentBLL();
                if(bllobj.AddStudentBL(objstudent)==false)
                {
                    throw new studentexception("Student Record not be Added");
                }
                else
                {
                    Console.WriteLine("Student Details added Suscesfully");
                }
            }
            catch (studentexception Exception)
            {
                Console.WriteLine("Error occcured"+Exception.Message);
            }
        }
        public static void SearchedStudentPl()
        {
            student searchedstudent = null;
            try
            {
                Console.WriteLine("enter the id is searched:");
                int studentId = Int32.Parse(Console.ReadLine());
                studentBLL student = new studentBLL();

                searchedstudent = student.searchstudentBLL(studentId);
                if(searchedstudent!=null)
                {
                    Console.WriteLine("searched student details");
                    Console.WriteLine("studentId:{0}",searchedstudent.Rollnumber);
                    Console.WriteLine("studentname:{0}", searchedstudent.Name);
                    Console.WriteLine("studentGrade:{0}", searchedstudent.Grade);
                }
            }
            catch(studentexception Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch(Exception Exception)
            {
                Console.WriteLine(Exception.Message);
            }
        }
        
        public static void DisplayStudentPL()
        {
            try
            {
                studentBLL bllobj = new studentBLL();
                List<student> slist = new List<student>();
                slist = bllobj.DisplayStudentBL();
                Console.WriteLine("Student details");
                Console.WriteLine("===============");
                foreach (student s in slist)
                {
                    Console.WriteLine("Student Id:{0} \t,StudentName:{1} \t,SttudentRollnumber:{2}\t",s.Rollnumber,s.Name,s.Name);
                }
            }
            catch(studentexception e)
            {
                Console.WriteLine(e.Message);
            }
        }

    }  
    
}
