﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FareCalculator
{
    class add
    {
        public int TotalKilometer { get; set; }
        public string VehicleType { get; set; }
        public int FareCaluclator( int TotalKilometer, string VehicleType)
        {
            int result = 0;
            string a = "Sedan";
            string b = "Mini";

            if(string.Equals(VehicleType,a))
            {
                int i = 0;
                i = 12;
                result = TotalKilometer * i;
                
            }
            else
            {
                Console.WriteLine("invalid entry");
            }

           
            if (string.Equals(VehicleType, b))
            {

                int i = 7;
                result = TotalKilometer * i;

            }
            else
            {
                Console.WriteLine("invalid entry");
            }

            return result;

        }
    }
}
