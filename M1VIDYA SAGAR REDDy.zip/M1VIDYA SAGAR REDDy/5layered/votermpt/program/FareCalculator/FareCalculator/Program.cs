﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FareCalculator
{
    class Program
    {
        static void Main(string[] args)
        {
            add a = new add();
            Console.WriteLine("enter total kilometers travelled");
            a.TotalKilometer = int.Parse(Console.ReadLine());
            Console.WriteLine(  "enter the vehicle type    sedan or mini");
            a.VehicleType = Console.ReadLine();
           
            Console.WriteLine("the total fare is {0}:" ,a.FareCaluclator(a.TotalKilometer, a.VehicleType));
        }
    }
}
