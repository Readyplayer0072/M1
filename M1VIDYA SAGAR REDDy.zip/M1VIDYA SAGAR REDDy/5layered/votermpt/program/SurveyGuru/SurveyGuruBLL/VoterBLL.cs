﻿using SurveyGuruDA;
using SurveyGuruEntity;
using SurveyGuruException;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SurveyGuruBLL
{
    /// <summary>
    /// to create the validation method and to invoke the operations from DAL
    /// Author: Atulya Mannava
    /// DOC: 8th oct 2018
    /// </summary>
    public class VoterBLL
    {
        static List<Voter> vList = new List<Voter>();


        public bool AddVoterBL(Voter voter)
        {
            bool isAdded = false;
            try
            {
                VoterDAL voterOperations = new VoterDAL();
                if (ValidateVoter(voter))
                {
                    isAdded = voterOperations.AddVoterDAL(voter);

                }
                else
                {
                    throw new VoterException("validation failed!! Voter details cannot be added");
                }
                if (isAdded == false)
                {
                    throw new VoterException("Voter details not added");
                }

            }
            catch (VoterException e)
            {
                throw e;
            }
            return isAdded;
        }
        private static bool ValidateVoter(Voter voter)
        {
            bool validvoter = true;
            StringBuilder message = new StringBuilder();
            if(voter.Id==null|| voter.Id.Length>8 || voter.Id.Length<8)
            {
                message.Append(Environment.NewLine + "id can not be blank or  more than 8");
                validvoter = false;
            }
                
            if (voter.Name == null || voter.Name == string.Empty || voter.Name.Length > 10||voter.Name.Length < 4 )
            {
                message.Append(Environment.NewLine + "name can not be blank or it cant be less than 4char or more than 8");
                validvoter = false;
            }
            if(voter.ReasonToVote==null|| voter.ReasonToVote.Length>200)
            {
                message.Append(Environment.NewLine + "reason cant be blank and it should not exceed 200char");
                validvoter = false;
            }
         
            if (validvoter == false)
            {
                throw new  VoterException(message.ToString());
            }
            return validvoter;
        }


        public List<Voter> DisplayVoterBL()
        {
            VoterDAL voterOperations = new VoterDAL();
            try
            {
                vList = voterOperations.DisplayVoterDAL();
                if (vList.Count <= 0)
                {
                    throw new VoterException("No Records Found!!");
                }

            }
            catch (VoterException e)
            {
                throw e;
            }
            return vList;
        }
        public Voter SearchVoterBLL(string Id)
        {
            Voter searchedVoter = null;
            try
            {
                VoterDAL voterDAL = new VoterDAL();
                searchedVoter = voterDAL.SearchedVoterDAL(Id);
                if (searchedVoter == null) throw new VoterException("voter not found");

            }
            catch (VoterException Exception) { throw Exception; }
            return searchedVoter;
        }
    }
}
