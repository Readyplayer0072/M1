﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SurveyGuruException
{
    /// <summary>
    /// Exception class to catch the exceptions occuring in Voter system
    /// Author: Atulya Mannava
    /// DOC: 8th oct 2018
    /// </summary>
    public class VoterException:ApplicationException
    {//default constructor, that inherits base constructor
        public VoterException() : base()
        {

        }
        //parameter constructor for passing the error/exception message
        public VoterException(string Message) : base(Message)
        {

        }
    }
}
