﻿using SurveyGuruBLL;
using SurveyGuruEntity;
using SurveyGuruException;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace SurveyGuruPL
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice;
            do
            {
                PrintMenu();
                Console.WriteLine("enter your choice:");
                bool chkChoice;

                chkChoice = int.TryParse(Console.ReadLine(), out choice);
                if (!chkChoice) { Console.WriteLine("invalid input"); }
                switch (choice)
                {
                    case 1:
                        AddVoterPL();
                        break;
                    case 2:
                        DisplayVoterPL();
                        break;
                    case 3:
                        SearchVoterPL();
                        break;
                    default:
                        Console.WriteLine("invalid choice");
                        break;
                }
            } while (choice != 0);
        }

        public static void PrintMenu()
        {
            Console.WriteLine("========================================");
            Console.WriteLine("VOTER INFORMATION SYSTEM (SMS)");
            Console.WriteLine("Press 1 to add new voter");
            Console.WriteLine("press 2 to diaplay all voters");
            Console.WriteLine("press 3 to search voter");
            Console.WriteLine("press 0 to exit");
            Console.WriteLine("=========================================");
        }
        public static void AddVoterPL()
        {
            try
            {
                Voter objVoter = new Voter();

                Console.WriteLine(" Enter The voter ID");
                string Id = Console.ReadLine();
                bool chkid1;
                if (Id.Length == 8)
                {
                    if (Id[2] == '-')
                    {

                        for (int i = 0; i < 2; i++)
                        {
                            if (!char.IsUpper(Id[i]))
                            {
                                chkid1 = false;
                                throw new VoterException("inavlid entry");

                            }

                            else
                            {
                                objVoter.Id = Id;
                            }
                        }
                    }
                    else
                    { Console.WriteLine("jsjkwsh"); }

                    for (int i = 3; i < 8; i++)
                    {
                        if (!char.IsNumber(Id[i]))
                        {
                            chkid1 = false;
                            throw new VoterException("inavlid entry1");
                        }
                        else
                        {
                            objVoter.Id = Id;
                        }
                    }
                }


                else
                {
                    throw new VoterException("invalid entry2");
                }



                Console.WriteLine("enter voter name");
                objVoter.Name = Console.ReadLine();

                Console.WriteLine("enter the Ward");
                objVoter.Ward = Console.ReadLine();

                if (objVoter.Ward == "North" || objVoter.Ward == "South" || objVoter.Ward == "East" || objVoter.Ward == "West")
                {
                }
                else
                {
                    Console.WriteLine("enter crct ward");
                }

                Console.WriteLine("enter the city");
                objVoter.City = Console.ReadLine();
                if (objVoter.City == "Banglore" || objVoter.City == "Mysore" || objVoter.City == "Hubli")
                {
                }
                else
                {
                    Console.WriteLine("enter crct city");
                }
                Console.WriteLine("Enter the phone number");
                objVoter.phoneno = Console.ReadLine();
                if (objVoter.phoneno.Length == 10)
                {


                    if (objVoter.phoneno[0] == char.Parse("7") || objVoter.phoneno[0] == char.Parse("8") || objVoter.phoneno[0] == char.Parse("9"))
                    {

                    }
                }
                else
                {
                    Console.WriteLine("phno is not valid");
                }


                Console.WriteLine("enter the party to vote for :");
                objVoter.PartyToVoteFor = Console.ReadLine();
                if (objVoter.PartyToVoteFor == "BJP" || objVoter.PartyToVoteFor == "Congress" || objVoter.PartyToVoteFor == "JD")
                {
                }
                else
                {
                    Console.WriteLine("enter crct party");
                }

                Console.WriteLine("enter the reason");
                objVoter.ReasonToVote = Console.ReadLine();
                Console.WriteLine("Enter the date");
                objVoter.votedate = DateTime.Parse(Console.ReadLine());
                Console.WriteLine("enter the mail id");
                objVoter.votermailid = Console.ReadLine();

                //string p, q;
                //p = "gmail.com";
                //q = "yahoo.com";
                for (int i = 0; i < objVoter.votermailid.Length; i++)
                {
                    if (objVoter.votermailid[i] == '@' || objVoter.votermailid[i] == '.')
                    {


                    }
                    //if (i < objVoter.votermailid.Length)
                    //{
                    //    objVoter.votermailid.Contains(p);
                    //    objVoter.votermailid.Contains(q);
                    //    Console.WriteLine("correct");

                    //}
                }
                VoterBLL bllobj = new VoterBLL();
                if (bllobj.AddVoterBL(objVoter) == false)
                {
                    throw new VoterException("Voter record could not be added");
                }
                else
                {
                    Console.WriteLine("Voter details added successfully");
                }
            }
            catch (VoterException Exception)
            {
                Console.WriteLine("error occured" + Exception.Message);
            }
        }
        public static void DisplayVoterPL()
        {
            try
            {
                VoterBLL bllobj = new VoterBLL();
                List<Voter> vList = new List<Voter>();

                vList = bllobj.DisplayVoterBL();
                Console.WriteLine("Voter details");
                Console.WriteLine("=================");
                foreach (Voter v in vList)

                {
                    Console.WriteLine("Voter ID : {0}  \t Voter Name  : {1}  \t  Voter Ward: {2} \t Voter city : {3} \t voter state :{4}  \t party to vote for : {5} \t Reason to vote : {6}",
                        v.Id, v.Name, v.Ward, v.City, Voter.State, v.PartyToVoteFor, v.ReasonToVote);

                }
            }
            catch (VoterException e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public static void SearchVoterPL()
        {
            Voter searchedVoter = null;
            try
            {
                Console.WriteLine("Enter Voter ID to be searched");
                string voterId = Console.ReadLine();

                VoterBLL voterBLL = new VoterBLL();
                searchedVoter = voterBLL.SearchVoterBLL(voterId);
                if (searchedVoter != null)
                {
                    Console.WriteLine("Searched voter details:");
                    Console.WriteLine("voter id : {0} ", searchedVoter.Id);
                    Console.WriteLine("voter name : {0} ", searchedVoter.Name);
                    Console.WriteLine("voter Ward : {0} ", searchedVoter.Ward);
                    Console.WriteLine("voter city :{0}", searchedVoter.City);
                    Console.WriteLine("voter state: {0}", Voter.State);
                    Console.WriteLine("voter party voted {0}", searchedVoter.PartyToVoteFor);
                    Console.WriteLine("voter party voted for the reason {0}", searchedVoter.ReasonToVote);


                }
            }
            catch (VoterException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (Exception Exception)
            {
                Console.WriteLine(Exception.Message);
            }

        }
    }
    

}


