﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SurveyGuruEntity
{


    /// <summary>
    /// To create the methods for performing operations on Voter entity
    /// Author: Atulya Mannava
    /// DOC: 8th oct 2018
    /// </summary>
    [Serializable]
    public class Voter
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Ward {get;set;}
        public string City { get; set; }
        public string phoneno { get; set; }
        public static string State="karnataka";
        public string PartyToVoteFor { get; set; }
        public string ReasonToVote { get; set; }
        public DateTime votedate { get; set; }
        public string votermailid { get; set; }
    }
  
    

}
