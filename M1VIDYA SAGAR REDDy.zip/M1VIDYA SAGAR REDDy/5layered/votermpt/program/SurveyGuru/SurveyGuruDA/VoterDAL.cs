﻿using SurveyGuruException;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using SurveyGuruEntity;

namespace SurveyGuruDA
{
    /// <summary>
    /// to create methods for performing operations on student entity
    /// Author: Atulya Mannava
    /// DOC: 8th Oct 2018
    /// </summary>
    public class VoterDAL
    {

        static List<Voter> voterList = new List<Voter>();
        /// <summary>
        /// Function for inserting data into the list
        /// </summary>
        /// <param name="newvoter"></param>
        /// <returns>boolean value if iser is added or not</returns>
        public bool AddVoterDAL(Voter newvoter)
        {
            bool isVoterAdded = false;
            try
            {
                voterList.Add(newvoter);
                SerializevoterDAL();
                isVoterAdded = true;
            }
            catch (VoterException)
            {
                throw;
            }
            return isVoterAdded;
        }


        ///<summary>
        ///function for serializing student list
        ///</summary>
        ///<returns>List of students</returns>
        public static void SerializevoterDAL()
        {
            FileStream fStream = null;
            try
            {
                fStream = new System.IO.FileStream("VoterList.ser", FileMode.Create, FileAccess.Write);
                BinaryFormatter Formatter = new BinaryFormatter();
                Formatter.Serialize(fStream, voterList);

            }
            catch (IOException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                fStream.Close();
            }
        }

        ///<summary>
        ///Function for displaying the data from the student List
        ///</summary>
        ///<returns>List of students</returns>
        public List<Voter> DisplayVoterDAL()
        {
            return DeserializeVoterDAL();
        }

        public static List<Voter> DeserializeVoterDAL()
        {
            List<Voter> deserializedData = null;
            FileStream fStream = null;
            try
            {
                fStream = new FileStream("VoterList.ser", FileMode.Open, FileAccess.Read);
                BinaryFormatter Formatter = new BinaryFormatter();
                deserializedData = (List<Voter>)Formatter.Deserialize(fStream);
            }
            catch (System.IO.IOException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                fStream.Close();
            }
            return deserializedData;
        }
        public Voter SearchedVoterDAL(string Id)

        {
            Voter searchedVoter;
            try
            {
                searchedVoter = voterList.Find(voter => voter.Id == Id);
            }
            catch (VoterException) { throw; }
            return searchedVoter;


        }
    }
}