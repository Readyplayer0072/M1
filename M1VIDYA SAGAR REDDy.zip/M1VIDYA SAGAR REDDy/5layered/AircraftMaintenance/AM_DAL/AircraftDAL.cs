﻿using AM_Entity;
using AM_Exception;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace AM_DAL
{

    ///<summary>
    ///To create method for performing operations in aircraft entity
    ///Author: Jaishree Sundar
    ///Date:08 oct 2018
    ///</summary>
    public class AircraftDAL
    {
        static List<aircraft> aircraftList = new List<aircraft>();

        ///<summary>
        ///Function for inserting data into list
        ///</summary>
        ///<param name="newaircraft"></param>
        ///<returns>boolean value if user is added or not</returns>
        public bool AddAircraftDAL(aircraft newaircraft)
        {
            bool IsAircraftAdded = false;
            try
            {
                aircraftList.Add(newaircraft);
                SerializeAircraftDAL();
                IsAircraftAdded = true;
            }
            catch (aircraftexception)
            {
                throw;
            }
            return IsAircraftAdded;
        }
        ///<summary>
        ///Function for serializing aircraft List
        /// </summary>
        /// <returns>list of aircraft</returns>
        public static void SerializeAircraftDAL()
        {
            FileStream fStream = null;
            try
            {
                fStream = new FileStream("AircraftList.ser", FileMode.Create, FileAccess.Write);
                BinaryFormatter Formatter = new BinaryFormatter();
                Formatter.Serialize(fStream, aircraftList);

            }
            catch (IOException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                fStream.Close();
            }
        }
        ///<summary>
        ///Function for displaying the data from aircraft list
        /// </summary>
        /// <returns> List of aircraft</returns>
        public List<aircraft> DisplayAircraftDAL()
        {
            return DeserializeAircraftDAL();
        }
        public static List<aircraft> DeserializeAircraftDAL()
        {
            List<aircraft> deserializedData = null;
            FileStream fStream = null;
            try
            {
                fStream = new FileStream("AircraftList.ser", FileMode.Open, FileAccess.Read);
                BinaryFormatter Formatter = new BinaryFormatter();
                deserializedData = (List<aircraft>)Formatter.Deserialize(fStream);
            }
            catch (IOException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                fStream.Close();
            }
            return deserializedData;
        }
        public aircraft SearchAircraftDAL(string AircraftID)
        {
            aircraft searchedaircraft;
            try
            {
                searchedaircraft = aircraftList.Find(aircraft => aircraft.AircraftID == AircraftID);
            }
            catch (aircraftexception)
            {
                throw;
            }
            return searchedaircraft;
        }
    }
}
