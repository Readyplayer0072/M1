﻿using AM_BLL;
using AM_Entity;
using AM_Exception;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AM_PL
{
    class Program
    {
        static void Main(string[] args)
        {
            int c;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter your choice");
                bool chkchoice;
                chkchoice = int.TryParse(Console.ReadLine(), out c);
                if (!chkchoice)
                {
                    Console.WriteLine("Invalid Input");
                }
                switch (c)
                {
                    case 1:
                        AddAircraftPL();
                        break;
                    case 2:
                        DisplayAircraftPL();
                        break;
                    case 3:
                        SearchAircraftPL();
                        break;
                    default:
                        Console.WriteLine("Invalid choice");
                        break;
                }
            } while (c != 0);
        }
        public static void PrintMenu()
        {
            Console.WriteLine("************************************************************");
            Console.WriteLine("Aircraft Management System");
            Console.WriteLine("Press 1 to Add new Aircraft Details");
            Console.WriteLine("Press 2 to Display Aircraft Details");
            Console.WriteLine("Press 3 to Search Aircraft Details");
            Console.WriteLine("************************************************************");
        }
        public static void AddAircraftPL()
        {
            try
            {
                aircraft objaircraft = new aircraft();
                Console.WriteLine("Enter the Aircraft ID:");
               
              
                string AircraftID = Console.ReadLine();
                StringBuilder b = new StringBuilder(AircraftID);
                
                if (AircraftID.Length == 7)
                {


                    if (char.IsUpper(b[0]) && char.IsUpper(b[1]))
                    {
                        if (b[2] == '-')
                        {
                            for (int i = 3; i < 7; i++)
                            {
                                if (char.IsNumber(b[i]))
                                {
                                    objaircraft.AircraftID = AircraftID;
                                }
                                else
                                {
                                    throw new aircraftexception("Invalid Entry");
                                }
                            }
                        }
                        else
                        {
                            throw new aircraftexception("Invalid Entry");
                        }

                    }
                }
                else
                {
                    throw new aircraftexception("Invalid Entry");
                }
                    
                Console.WriteLine("Enter Aircraft Type");
                string AircraftType = Console.ReadLine();
                if(AircraftType=="Jet"||AircraftType=="ATR")
                {
                    objaircraft.AircraftType = AircraftType;
                }
                else
                {
                    throw new aircraftexception("Type Cant be different");
                }

                Console.WriteLine("Enter the Aircraft Model");
                string AircraftModel = Console.ReadLine();
                StringBuilder a = new StringBuilder(AircraftModel);
                if (AircraftModel.Length == 6)
                {


                    if (char.IsUpper(a[0]) && char.IsUpper(a[1]))
                    {
                        if (char.IsNumber(a[2]))
                        {
                            for (int i = 3; i < 6; i++)
                            {
                                if (char.IsLetter(a[i]))
                                {
                                    objaircraft.AircraftModel = AircraftModel;
                                }
                                else
                                {
                                    throw new aircraftexception("Invalid Entry");
                                }
                            }
                        }
                        else
                        {
                            throw new aircraftexception("Invalid Entry");
                        }

                    }
                    else
                    {
                        throw new aircraftexception("Invalid Entry");
                    }
                }
                else
                {
                    throw new aircraftexception("Invalid Entry");
                }


                Console.WriteLine("Enter the Aircraft Make");
                objaircraft.AircraftMake = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Maintenance Type");
                objaircraft.MaintType = Console.ReadLine();
                Console.WriteLine("Enter Maintenance Issue");
                objaircraft.MaintIssue = Console.ReadLine();

                Console.WriteLine("Enter Manufacturer Name");
                string Manufby = Console.ReadLine();
                if(Manufby=="Boeing"|| Manufby=="Airbus")
                {
                    objaircraft.Manufby = Manufby;
                }
                else
                {
                    throw new aircraftexception("Invalid Manufacturer Name");
                }
                Console.WriteLine("Enter the Manufacturing Date");
                objaircraft.ManufDate = DateTime.Parse(Console.ReadLine());


                AircraftBLL bllobj = new AircraftBLL();
                if (bllobj.AddAircraftBL(objaircraft) == false)
                {
                    throw new aircraftexception("Aircraft record couldnot be added");
                }
                else
                {
                    Console.WriteLine("Aircraft details added successfully");
                }
            }
            catch (aircraftexception exception)
            {
                Console.WriteLine("Error Occurred" + exception.Message);
            }
        }
        public static void DisplayAircraftPL()
        {
            try
            {
                AircraftBLL bllobj = new AircraftBLL();
                List<aircraft> sList = new List<aircraft>();
                sList = bllobj.DisplayAircraftBL();
                Console.WriteLine("Aircraft Details");
                Console.WriteLine("*************************************");
                foreach (aircraft s in sList)
                {
                    Console.WriteLine("Aircraft Id:{0}\nAircraft Type:{1}\nAircraft Model:{2}\nAircraft Make:{3}\nManfacturer:{4}\nManufactured Date:{5}\nMaintenance Type:{6}\nMaintenance Issue:{7}", s.AircraftID, s.AircraftType, s.AircraftModel,s.AircraftMake,s.Manufby,s.ManufDate,s.MaintType,s.MaintIssue);
                }
            }
            catch (aircraftexception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        private static void SearchAircraftPL()
        {
            aircraft searchedaircraft = null;
            try
            {
                Console.WriteLine("Enter Aircraft ID to be searched");
                string AircraftID = Console.ReadLine();
                AircraftBLL aircraftBLL = new AircraftBLL();
                searchedaircraft = aircraftBLL.SearchAircraftBLL(AircraftID);
                if (searchedaircraft != null)
                {
                    Console.WriteLine("Searched Aircraft Details:");
                    Console.WriteLine("Aircraft ID:{0}", searchedaircraft.AircraftID);
                    Console.WriteLine("Aircraft Type:{0}", searchedaircraft.AircraftType);
                    Console.WriteLine("Aircraft Model:{0}", searchedaircraft.AircraftModel);
                    Console.WriteLine("Aircraft Make:{0}", searchedaircraft.AircraftMake);
                    Console.WriteLine("Manufacturer Name:{0}", searchedaircraft.Manufby);
                    Console.WriteLine("Manufactured Date:{0}", searchedaircraft.ManufDate);
                }
            }
            catch (aircraftexception exception)
            {
                Console.WriteLine(exception.Message);
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception.Message);
            }
        }
    }
}

