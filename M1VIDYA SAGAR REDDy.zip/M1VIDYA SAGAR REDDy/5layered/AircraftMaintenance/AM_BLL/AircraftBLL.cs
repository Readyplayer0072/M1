﻿using AM_DAL;
using AM_Entity;
using AM_Exception;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AM_BLL
{
    ///<summary>
    ///To create the validation method and to invoke the operation from DAL
    ///Author: Jaishree Sundar
    ///Date:08 oct 2018
    ///</summary>
    public class AircraftBLL
    {
        static List<aircraft> sList = new List<aircraft>();
        public bool AddAircraftBL(aircraft aircraft)
        {
            bool IsAdded = false;
            try
            {
                AircraftDAL aircraftOperations = new AircraftDAL();
                if (ValidateAircraft(aircraft))
                {
                    IsAdded = aircraftOperations.AddAircraftDAL(aircraft);
                }
                else
                {
                    throw new aircraftexception("Validation Failed");
                }
                if (IsAdded == false)
                {
                    throw new aircraftexception("Aircraft Details not Added");
                }
            }
            catch (aircraftexception e)
            {
                throw e;
            }
            return IsAdded;
        }
        private static bool ValidateAircraft(aircraft aircraft)
        {
            bool validaircraft = true;
            StringBuilder message = new StringBuilder();
            if (aircraft.AircraftID.Length <7)
            {
                message.Append(Environment.NewLine + "Invalid ID");
                validaircraft = false;
            }
           
            if (aircraft.AircraftType == null || aircraft.AircraftType == string.Empty)
            {
                message.Append(Environment.NewLine + "Name cant be blank");
                validaircraft = false;
            }
            if (aircraft.AircraftModel == null || aircraft.AircraftModel == string.Empty)
            {
                message.Append(Environment.NewLine + "Model Name cant be blank");
                validaircraft = false;
            }
            if (aircraft.Manufby == null || aircraft.Manufby == string.Empty)
            {
                message.Append(Environment.NewLine + " Manufacturer Name cant be blank");
                validaircraft = false;
            }
            if (validaircraft == false)
            {
                throw new aircraftexception(message.ToString());
            }
            return validaircraft;
        }
        public List<aircraft> DisplayAircraftBL()
        {
            AircraftDAL aircraftOperations = new AircraftDAL();
            try
            {
                sList = aircraftOperations.DisplayAircraftDAL();
                if (sList.Count <= 0)
                {
                    throw new aircraftexception("No records found");
                }
            }
            catch (aircraftexception e)
            {
                throw e;
            }
            return sList;
        }
        public aircraft SearchAircraftBLL(string AircraftID)
        {
            aircraft searchedaircraft = null;
            try
            {
                AircraftDAL aircraftDAL = new AircraftDAL();
                searchedaircraft = aircraftDAL.SearchAircraftDAL(AircraftID);
                if (searchedaircraft == null)
                    throw new aircraftexception("Aircraft details not found");
            }
            catch (aircraftexception exception)
            {
                throw exception;
            }
            return searchedaircraft;
        }
    }
}
