﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AM_Exception
{
    ///<summary>
    ///Exception class to catch exception occuring in AM
    ///Author: Jaishree Sundar
    ///Date:08 oct 2018
    ///</summary>
    public class aircraftexception:ApplicationException
    {

        //Default constructor:inherits the base constructor
        public aircraftexception() : base()
        {

        }
        //Parameterized constructor:for passing exception message
        public aircraftexception(string Message) : base(Message)
        {

        }
    }
}
