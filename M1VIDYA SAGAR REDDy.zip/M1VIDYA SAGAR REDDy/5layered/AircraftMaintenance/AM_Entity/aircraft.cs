﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AM_Entity
{
    ///<summary>
    ///To create the methods for performing operations in aircraft entity
    ///Author: Jaishree Sundar
    ///Date:08 oct 2018
    ///</summary>
    [Serializable]
    public class aircraft
    {
        public string AircraftID { get; set; }
        public string AircraftType { get; set; }
        public string AircraftModel { get; set; }
        public int AircraftMake { get; set; }
        public string Manufby { get; set; }
        public DateTime ManufDate { get; set; }
        public string MaintType { get; set; }
        public string MaintIssue { get; set; }
    }
}
