﻿using SGDAL;
using SGEntities;
using SGExceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGBLL
{
    public class VoterBLL
    {
        static List<Voter> sList = new List<Voter>();
        public bool AddVoterBL(Voter voter)
        {
            bool isAdded = false;
            try
            {
                VoterDAL voterOperations = new VoterDAL();
                if (ValidateVoter(voter))
                { isAdded = voterOperations.AddVoterDAL(voter); }

                else { throw new VoterException("Validation Failed!!! "); }
                if (isAdded == false)
                {
                    throw new VoterException("Voter Details Not Added");
                }
            }
            catch (VoterException e)
            {
                throw e;
            }
            return isAdded;


        }
        private static bool ValidateVoter(Voter voter)
        {
            bool validvoter = true;
            StringBuilder message = new StringBuilder();

            if (voter.VoterId.Length > 7 || voter.VoterId.Length < 0)
            {
                message.Append(Environment.NewLine + " Voter Id Length Should be 7 Characters");
                validvoter = false;
            }
            if (voter.VoterName == null || voter.VoterName == string.Empty)
            {
                message.Append(Environment.NewLine + "Name cannot be Empty");
                validvoter = false;
            }
            if (voter.VoterName.Length < 4 || voter.VoterName.Length > 8)
            {
                message.Append(Environment.NewLine + "Name Should be between 4-8 characters");
                validvoter = false;

            }
            if (voter.ReasonToVote.Length > 200)
            { message.Append(Environment.NewLine + "Reason Length should be below 200 Characters"); validvoter = false;
            }
            else if (voter.ReasonToVote.Length < 0)
            { message.Append(Environment.NewLine + "Do not leave Blank"); validvoter = false;
            }
            
            if (validvoter == false)
            { throw new VoterException(message.ToString()); }

            return validvoter;

        }
        public List<Voter> DisplayVoterBL()
        {
            VoterDAL voterOperations = new VoterDAL();
            try
            {
                sList = voterOperations.DisplayVoterDAL();
                if (sList.Count <= 0)
                {
                    throw new VoterException("No Records Found!!!");
                }

            }
            catch (VoterException e)
            {
                throw e;
            }
            return sList;

        }

        public Voter SearchVoterBLL(string VoterId)
        {
            Voter searchVoter = null;
            try
            {
                VoterDAL voterDAL = new VoterDAL();
                searchVoter = voterDAL.SearchVoterDAL(VoterId);
                if (searchVoter == null)
                    throw new VoterException("Voter Not Found");
            }
            catch (VoterException Exception) { throw Exception; }
            return searchVoter;

        }

        }
    }

