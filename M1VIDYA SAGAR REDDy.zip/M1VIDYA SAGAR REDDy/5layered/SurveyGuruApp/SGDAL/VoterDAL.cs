﻿using SGEntities;
using SGExceptions;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace SGDAL
{
    public class VoterDAL

    { 
        static List<Voter> voterList = new List<Voter>();

    public bool AddVoterDAL(Voter newvoter)
    {
        bool isVoterAdded = false;
        try
        {
            voterList.Add(newvoter);
            SerializeVoterDAL();
            isVoterAdded = true;
        }
        catch
        {
            throw;
        }
        return isVoterAdded;
    }

    public static void SerializeVoterDAL()
    {
        FileStream fStream = null;

        try
        {
            fStream = new FileStream("VoterList.ser", FileMode.Create, FileAccess.Write);
            BinaryFormatter Formatter = new BinaryFormatter();
            Formatter.Serialize(fStream, voterList);
        }
        catch (IOException)
        {
            throw;
        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            fStream.Close();
        }

    }

    public List<Voter> DisplayVoterDAL()
    {
        return DeserializeVoterDAL();
    }

    public static List<Voter> DeserializeVoterDAL()
    {

        List<Voter> deserializeData = null;
        FileStream fStream = null;

        try
        {
            fStream = new FileStream("VoterList.ser", FileMode.Open, FileAccess.Read);
            BinaryFormatter Formatter = new BinaryFormatter();
            deserializeData = (List<Voter>)Formatter.Deserialize(fStream);
        }
        catch (IOException)
        {
            throw;
        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            fStream.Close();
        }
        return deserializeData;

    }

    public Voter SearchVoterDAL(string VoterId)
    {
        Voter searchedVoter;
        try
        {
            searchedVoter = voterList.Find(voter => voter.VoterId == VoterId);
        }
        catch (VoterException) { throw; }
        return searchedVoter;
    }






}
}
