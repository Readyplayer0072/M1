﻿using SGBLL;
using SGEntities;
using SGExceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGPL
{ [Serializable]
    class Program
    {
        static void Main(string[] args)
        {
            int choice;
            Console.WriteLine("************************Voter Management System**************************");
            do
            {
                PrintMenu();
                Console.WriteLine("Enter Your Choice");
                bool chkChoice;
                chkChoice = int.TryParse(Console.ReadLine(), out choice);
                if (!chkChoice) { Console.WriteLine("Invalid Input"); }
                switch (choice)
                {
                    case 1:
                        AddVoterPL();
                        break;
                    case 2:
                       DisplayVoterPL();
                        break;
                    case 3:
                       SearchVoterPL();
                        break;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;


                }
            } while (choice != 0);
        }
        static void PrintMenu()
        {
            Console.WriteLine("Enter 1 to Add Details");
            Console.WriteLine("Enter 2 to View Details");
            Console.WriteLine("Enter 3 to Search Details");
            Console.WriteLine("Enter 0 to Exit");
            Console.WriteLine("*************************************************************************");


        }

        public static void AddVoterPL()
        {
            
            try
            {
                Voter objVoter = new Voter();
                Console.WriteLine("Enter Voter ID");
               
                
                objVoter.VoterId = Console.ReadLine();
                Console.WriteLine("Enter Voter Name:");
                objVoter.VoterName = Console.ReadLine();
                Console.WriteLine("Enter Voter Ward from North, South,East & West:");
                objVoter.Ward = (Ward)Enum.Parse(typeof(Ward), Console.ReadLine());
                Console.WriteLine("Enter Voter City from Bangalore, Mysore & JD:");
                objVoter.City = (City)Enum.Parse(typeof(City), Console.ReadLine());
                Console.WriteLine("Enter Voter Party To Vote Forfrom Congress, BJP & JD:");
                objVoter.PartytoVoteFor = (PartyToVoteFor)Enum.Parse(typeof(PartyToVoteFor), Console.ReadLine());
                Console.WriteLine("Enter Reason To Vote:");
                objVoter.ReasonToVote = Console.ReadLine();

                VoterBLL bllobj = new VoterBLL();
                if (bllobj.AddVoterBL(objVoter) == false)
                {
                    throw new VoterException("Voter Record could not be added");
                }
                else
                { Console.WriteLine("Voter Details Added Successfully"); }
            }
            catch (VoterException Exception)
            {
                Console.WriteLine("Error Ocurred" + Exception.Message);
            }

        }
        public static void DisplayVoterPL()
        {
            try
            {
                VoterBLL bllobj = new VoterBLL();
                List<Voter> sList = new List<Voter>();
                sList = bllobj.DisplayVoterBL();
                Console.WriteLine("Voter Details");
                Console.WriteLine("===============");
                foreach (Voter v in sList)
                {
                    Console.WriteLine($"Voter ID:{v.VoterId}\nVoter Name:{v.VoterName}\nVoter Ward:" +
                        $"{v.Ward}\nCity:{v.City}\nState:{v.State}\nParty To Vote For:{v.PartytoVoteFor}\nReasonToVote:{v.ReasonToVote}");
                }
            }
            catch (VoterException e)
            {
                Console.WriteLine(e.Message);
            }

        }
        private static void SearchVoterPL()
        {
            Voter searchedVoter = null;
            try
            {

                Console.WriteLine("Enter Voter ID to be Searched:");
                string VoterID = Console.ReadLine();
                VoterBLL studentBLL = new VoterBLL();
                searchedVoter = studentBLL.SearchVoterBLL(VoterID);
                if (searchedVoter != null)
                {
                    Console.WriteLine("Searched Voter Details:");
                    Console.WriteLine($"Voter ID:{searchedVoter.VoterId}\nVoter Name:{searchedVoter.VoterName}\nWard:{searchedVoter.Ward}\nCity:" +
                        $"{searchedVoter.City}\nState:{searchedVoter.State}\nParty To Vote For:{searchedVoter.PartytoVoteFor}\nReason To Vote:{searchedVoter.ReasonToVote}");
                }
            }
            catch (VoterException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (Exception Exception)
            {
                Console.WriteLine(Exception.Message);
            }

        }


    }
}
