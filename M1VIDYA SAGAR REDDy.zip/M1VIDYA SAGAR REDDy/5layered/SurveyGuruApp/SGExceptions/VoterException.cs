﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGExceptions
{
    public class VoterException:ApplicationException
    {
        public VoterException() : base()
        { }

        public VoterException(string Message) : base(Message)
        { }
    }
}
