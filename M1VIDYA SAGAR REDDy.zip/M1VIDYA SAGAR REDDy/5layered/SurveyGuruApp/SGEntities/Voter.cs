﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGEntities
{[Serializable]
    public class Voter
    {
        public string VoterId{ get; set; }
        public string VoterName { get; set; }
        public Ward Ward { get; set; }
        public string State { get; } = "Karnataka";
        public City City { get; set; }
        public PartyToVoteFor PartytoVoteFor { get; set; }
        public string ReasonToVote { get; set; }

    }
   public enum Ward { North, South, East, West }
   public enum City { Bangalore, Mysore, Hubli }
   public enum PartyToVoteFor { Congress, BJP, JD }
}
