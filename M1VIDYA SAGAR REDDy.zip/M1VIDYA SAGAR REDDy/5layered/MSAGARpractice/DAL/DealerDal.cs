﻿using DealerException;
using MSAGARpractice;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class DealerDAL
    {
        static List<dealer> dealerList = new List<dealer>();
        ///<summary>
        ///Function for inserting data into the list 
        ///</summary>
        ///<param name="newdealer"></param>
        ///<returns>boolean value if user is added or not</returns>
        public bool AddDealerDAL(dealer newdealer)
        {
            bool isDealerAdded = false;
            try
            {
                dealerList.Add(newdealer);
                SerializeDealerDAL();
                isDealerAdded = true;
            }
            catch (dealerException)
            {
                throw;
            }
            return isDealerAdded;
        }
        public static void SerializeDealerDAL()
        {
            FileStream fileStream = null;
            try
            {
                fileStream = new FileStream("dlist.ser", FileMode.Create, FileAccess.Write);
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(fileStream, dealerList);
            }
            catch (IOException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;

            }
            finally
            {
                fileStream.Close();
            }

        }
        public List<dealer> DisplayDealerDAL()
        {
            return DeserializeDealerDAL();
        }
        public static List<dealer> DeserializeDealerDAL()
        {
            List<dealer> deserializeData = null;
            FileStream fstream = null;
            try
            {
                fstream = new FileStream("dealerlist.ser", FileMode.Open, FileAccess.Read);
                BinaryFormatter Formatter = new BinaryFormatter();
                deserializeData = (List<dealer>)Formatter.Deserialize(fstream);
            }
            catch (IOException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                fstream.Close();
            }
            return deserializeData;
        }
        public dealer SearchDealerDAL(string DealerID)
        {
            dealer searchedDealer;
            try
            {
                searchedDealer = dealerList.Find(dealer => dealer.DealerID == DealerID);
            }
            catch (dealerException)
            {
                throw;
            }
            return searchedDealer;
        }
    }
}
