﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DealerException
{
    public class dealerException:ApplicationException
    {
       
           
           public dealerException() : base()
        {

        }
         
            
            public dealerException(string message) : base(message)
            {

            }

        
    }
}
