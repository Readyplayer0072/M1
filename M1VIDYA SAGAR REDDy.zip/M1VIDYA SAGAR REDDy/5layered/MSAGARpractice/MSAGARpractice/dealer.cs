﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MSAGARpractice
{[Serializable]
    public class dealer
    {
        public string DealerID { get; set; }
        public string DealerName { get; set; }
        public string DealerAddress { get; set; }
        public string DealerEmailID { get; set; }
        public string DealerPhoneNo { get; set; }
        public string DealerStatus { get; set; }
        public string DealerProductCategory { get; set; }
    } 
}
