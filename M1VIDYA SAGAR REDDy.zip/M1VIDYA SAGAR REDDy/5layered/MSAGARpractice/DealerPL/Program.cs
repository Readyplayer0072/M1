﻿using BLL;
using DealerException;
using MSAGARpractice;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DealerPL
{
    class program
    {
        static void Main(string[] args)
        {
            int choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter Your Choice");
                bool chkChoice;
                chkChoice = int.TryParse(Console.ReadLine(), out choice);
                if (!chkChoice)
                {
                    Console.WriteLine(("Invalid Input:"));
                }
                switch (choice)
                {
                    case 1:
                        AddDealerPL();
                        break;
                    case 2:
                        DisplayDealerPL();
                        break;
                    case 3:
                        SearchDealerPL();
                        break;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            }
            while (choice != 0);

        }

        public static void PrintMenu()
        {
            Console.WriteLine("============================================================");
            Console.WriteLine("Dealer Records");
            Console.WriteLine("Press 1 to ADD New Dealer");
            Console.WriteLine("Press 2 to Display All Dealers");
            Console.WriteLine("Press 3 to Search Dealer");
            Console.WriteLine("Press 0 to Exit");
            Console.WriteLine("============================================================");
        }
        public static void AddDealerPL()
        {
            dealer obj = new dealer();
            try
            {
                Console.WriteLine("Enter dealer id");
                string DealerID = Console.ReadLine();
                if (DealerID.Length == 6)
                {
                    if (DealerID[0] == 'D' && DealerID[1] == 'L')
                    {
                        obj.DealerID = DealerID;
                    }
                    else
                    {
                        throw new dealerException("invalid entry");
                    }

                }
                else
                {
                    throw new dealerException("invalid entry 2");
                }

                Console.WriteLine("Enter Dealer Name");
                obj.DealerName = Console.ReadLine();
                Console.WriteLine("Enter Dealer Address");
                obj.DealerAddress = Console.ReadLine();

                Console.WriteLine("Enter mailid");
                string DealerEmailID = Console.ReadLine();
                if (char.IsLetter(DealerEmailID[0]))
                {
                    if (DealerEmailID.Contains("@gmail.com") || DealerEmailID.Contains("@yahoo.com"))
                    {
                        obj.DealerEmailID = DealerEmailID;
                    }

                    else
                    {
                        throw new dealerException("enter vaid email id");
                    }
                }
                else
                {
                    throw new dealerException("enter vaid email id");
                }
                Console.WriteLine("Enter phone number");
                string DealerPhoneNo = Console.ReadLine();
                if (DealerPhoneNo.Length == 10)
                {
                    if (DealerPhoneNo[0] == '7' || DealerPhoneNo[0] == '8' || DealerPhoneNo[0] == '9')
                    {
                        obj.DealerPhoneNo = DealerPhoneNo;
                    }
                    else
                    {
                        throw new dealerException("invaid phone number .Enter valid number");
                    }

                }
                Console.WriteLine("Enter status");
                string DealerStatus = Console.ReadLine();
                if (DealerStatus == "Active" || DealerStatus == "Inactive")
                {
                    obj.DealerStatus = DealerStatus;
                }
                else
                {
                    throw new dealerException("invalid status .Enter either active or inactivee");
                }
                Console.WriteLine("Enter dealer category");
                string DealerProductCategory = Console.ReadLine();
                if (DealerProductCategory == "fruits" || DealerProductCategory == "vegetables" || DealerProductCategory == "Bakery" || DealerProductCategory == "meat")
                {
                    obj.DealerProductCategory = DealerProductCategory;
                }
                else
                {
                    throw new dealerException("invalid category.Enter any of the abov ones");
                }
                DealerBLL objDB = new DealerBLL();
                if (objDB.AddDealerBLL(obj) == false)
                {
                    throw new dealerException(" Dealer record not found");
                }
                else
                {
                    Console.WriteLine(" Dealer details added successfully");
                }

            }
            catch (dealerException Exception)
            {
                Console.WriteLine("error occured" + Exception.Message);
            }
        }
        public static void DisplayDealerPL()
        {
            try
            {
                DealerBLL bllobj = new DealerBLL();
                List<dealer> sList = new List<dealer>();
                sList = bllobj.DisplayDealerBL();
                Console.WriteLine("Dealer details");
                Console.WriteLine("=================================================");
                foreach (dealer D in sList)
                {
                    Console.WriteLine("DealerID:{0}\t DealerName:{1}\t DealerAddress:{2}\t" +
                        "DealerEmailID:{3}\t DealerPhoneNo:{4}\t DealerStatus:{5}\t DealerProductCategory:{6}\t",
                        D.DealerID, D.DealerName, D.DealerAddress, D.DealerEmailID, D.DealerPhoneNo, D.DealerStatus,
                        D.DealerProductCategory);
                }
            }
            catch (dealerException e)
            {
                Console.WriteLine(e.Message);
            }
        }
        private static void SearchDealerPL()
        {
            dealer searchedDealer = null;
            try
            {
                Console.WriteLine("Enter Dealer id to be searched:");
                string DealerID = Console.ReadLine();
                DealerBLL dealerBLL = new DealerBLL();
                searchedDealer = dealerBLL.SearchDealerBLL(DealerID);
                if (searchedDealer != null)
                {
                    Console.WriteLine("Searched dealer details");
                    Console.WriteLine("dealer id:{0}", searchedDealer.DealerID);
                    Console.WriteLine("dealer Name:{0}", searchedDealer.DealerName);
                    Console.WriteLine("dealer Address:{0}", searchedDealer.DealerAddress);
                    Console.WriteLine("dealer emailid:{0}", searchedDealer.DealerEmailID);
                    Console.WriteLine("dealer phoneno:{0}", searchedDealer.DealerPhoneNo);
                    Console.WriteLine("dealer status:{0}", searchedDealer.DealerStatus);
                    Console.WriteLine("dealer productcategory:{0}", searchedDealer.DealerProductCategory);

                }
            }
            catch (dealerException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (Exception Exception)
            {
                Console.WriteLine(Exception.Message);
            }




        }
    }
}   

