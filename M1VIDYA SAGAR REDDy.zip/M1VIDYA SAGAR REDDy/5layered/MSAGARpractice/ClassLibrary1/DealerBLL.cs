﻿using DAL;
using DealerException;
using MSAGARpractice;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class DealerBLL
    {

        List<dealer> sList = new List<dealer>();
        public bool AddDealerBLL(dealer dealer)
        {
            bool isAdded = false;
            try
            {
                DealerDAL operations = new DealerDAL();
                if (validatedealer(dealer))
                {
                    isAdded = operations.AddDealerDAL(dealer);
                    Console.WriteLine("valid detail are given");
                }
                else
                {
                    throw new dealerException("validation failed!product details cannot be added");
                }
                if (isAdded == false)
                {
                    throw new dealerException("product details not added");
                }

            }
            catch (dealerException D1)
            {
                throw D1;

            }
            return isAdded;
        }

        private static bool validatedealer(dealer Dealer)
        {
            bool isvalid = true;

            StringBuilder message = new StringBuilder();
            if (Dealer.DealerName == null || Dealer.DealerName == string.Empty)
            {
                message.Append(Environment.NewLine + "name can not be blank ");
                isvalid = false;
            }
            if(Dealer.DealerEmailID==null||Dealer.DealerName==string.Empty)
            {
                message.Append(Environment.NewLine + "Mail Cannot Be Blank");
                isvalid = false;
            }

            if (isvalid == false)
            {
                throw new dealerException(message.ToString());
            }
            return isvalid;
        }
        public List<dealer> DisplayDealerBL()
        {
            DealerDAL Dealeroperations = new DealerDAL();
            try
            {
                sList = Dealeroperations.DisplayDealerDAL();
                if (sList.Count <= 0)
                {
                    throw new dealerException("no records found!!!");
                }
            }
            catch (dealerException e)
            {
                throw e;
            }
            return sList;
        }
        public dealer SearchDealerBLL(string DealerID)
        {
            dealer searchedDealer = null;
            try
            {
                DealerDAL dealerDAL = new DealerDAL();
                searchedDealer = dealerDAL.SearchDealerDAL(DealerID);
                if (searchedDealer == null) throw new dealerException("Dealer not found");
            }
            catch (dealerException Exception)
            {
                throw Exception;
            }

            return searchedDealer;

        }


    }
}
