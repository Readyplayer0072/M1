﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace fileIO
{
    class directortinfodemo
    {
        static void Main(string[] args)
       
        {
            DirectoryInfo directoryInfo = new DirectoryInfo(@"C: \Users\lungidance\source\repos\fileIO\fileIO");
            Console.WriteLine("directories in the given directory are:");
            foreach (DirectoryInfo directory in directoryInfo.GetDirectories())
            {
                Console.WriteLine( "\t"+directory.Name );
                Console.WriteLine(" \t parent directory:"+directory.Parent);
                Console.WriteLine("\t last acessed at:"+directory.LastWriteTime);
            }
            Console.WriteLine("files in the given ditectory are:");
            foreach (FileInfo file   in directoryInfo.GetFiles())
            {
                Console.WriteLine(file.Name);
                Console.WriteLine("creation time:"+file.CreationTime);
                Console.WriteLine("last written time:"+file.LastWriteTime);
                Console.WriteLine("extension:"+file.Extension);
            }
        }
    }
}
