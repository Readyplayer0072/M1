﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace fileIO
{
    class IOStreamdemo
    {
        static void Main(string[] args)
        {
            FileStream filestream = new FileStream("my data.txt", FileMode.Create);
            string userinput = Console.ReadLine();

            Byte[] data = new Byte[userinput.Length];
            data = Encoding.ASCII.GetBytes(userinput);

            filestream.Write(data, 0, data.Length);
            filestream.Close();
            Console.WriteLine("data written to the file.");


            FileStream filestream1 = new FileStream("my data.txt", FileMode.Open); 
            Byte[] readdata = new Byte[100];
            filestream1.Read(readdata, 0, readdata.Length);
            Console.WriteLine(Encoding.ASCII.GetString(readdata));
            //filestream.Write(data, 0, data.Length);
            filestream1.Close();
            //Console.WriteLine("data written to the file.");


        }
    }
}
