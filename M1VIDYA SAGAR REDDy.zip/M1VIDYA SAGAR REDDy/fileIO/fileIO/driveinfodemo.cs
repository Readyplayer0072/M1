﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace fileIO
{
    class driveinfodemo
    {
        static void Main(string[] args)
        {
            DriveInfo driveinfo = new DriveInfo(@"C: \Users\lungidance\source\repos\fileIO\fileIO");
            Console.WriteLine("drive name:"+driveinfo.Name);
            Console.WriteLine("Root Directory:"+driveinfo.RootDirectory);
            Console.WriteLine("TotalSize:"+driveinfo.TotalFreeSpace);
            Console.WriteLine("TotalSize:"+driveinfo.TotalSize);
            Console.WriteLine("driveformat:"+driveinfo.DriveFormat);
        }
    }
}
