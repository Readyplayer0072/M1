﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesDemo
{
    public delegate T Mydelegate2<T>(T x, T y);
    class Generic_Delegates
    {
        static int Sum(int x, int y)
        {
          return x+y;
        }
        static double Subtract(double x, double y)
        {
            return x - y;
        }
        static double Multiply(double x, double y)
        {
            return x * y;
        }
        static void Main(string[] args)
        {
            Mydelegate2<int> myDelegate21 = new Mydelegate2<int>(Sum);
            Console.WriteLine(myDelegate21(10, 20));
            Mydelegate2<double> myDelegate22 = new Mydelegate2<double>(Subtract);
            Console.WriteLine(myDelegate22(10, 20));
            Mydelegate2<double> myDelegate23 = new Mydelegate2<double>(Multiply);
            Console.WriteLine(myDelegate23(10, 20));
        }
    }
}
 