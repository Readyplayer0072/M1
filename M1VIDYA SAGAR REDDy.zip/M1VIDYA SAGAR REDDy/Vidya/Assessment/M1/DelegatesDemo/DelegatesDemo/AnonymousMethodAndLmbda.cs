﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesDemo
{
    public delegate int MyDelegate3(int x, int y);
    class AnonymousMethodAndLmbda
    {
       
        static void Main(string[] args)
        {
            //MyDelegate3 myDelegate3 = delegate (int x, int y)
            //{
            //    return x + y;
            //};

            MyDelegate3 myDelegate3 =(x, y) =>{ return x + y; };
              Console.WriteLine(myDelegate3(10, 20));
        }
    }
}
