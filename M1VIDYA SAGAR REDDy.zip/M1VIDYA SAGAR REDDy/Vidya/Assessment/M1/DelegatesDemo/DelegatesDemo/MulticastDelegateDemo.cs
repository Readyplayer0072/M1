﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesDemo
{
    public delegate void Mydelegate1(double x,double y);
    class MulticastDelegateDemo
    {
        static void Sum(double x, double y)
        {
            Console.WriteLine("Sum = " + (x+y));
        }
        static void Subtract(double x, double y)
        {
            Console.WriteLine("Difference = " + (x - y));
        }
        static void Multiply    (double x, double y)
        {
            Console.WriteLine("Product = " + (x * y));
        }
        static void Divide(double x, double y)
        {
            Console.WriteLine("Divison = " + (x / y));
        }
        static void Main(string[] args)
        {
            Mydelegate1 myDelegate1 = new Mydelegate1(Sum);
            myDelegate1 += Subtract;
            myDelegate1 += Multiply ;
            myDelegate1 += Divide;
            myDelegate1(12.30, 23.90);



        }
    }
}
