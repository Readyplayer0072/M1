﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesDemo
{
    public delegate void Mydelegate();
    class Program
    {
       public static void Display()
        {
            Console.WriteLine("Inside Display()");
        }
        public static void Show()
        {
            Console.WriteLine("Inside Show()");
        }
        static void Main(string[] args)
        {
            Mydelegate myDelegate1 = new Mydelegate(Display);
            Mydelegate myDelegate2 = new Mydelegate(Show);

            myDelegate1();
            myDelegate2();
        }
    }
}
