﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordCounter
{
    /// <summary>
    ///  to create an extension method on string class to count the number of words in a sentence
    ///  Author: Nikita
    ///  DOC:8rd Oct 2018
    ///  </summary>
    class Program
    {
        /// <summary>
        ///  main function to read input string, call extension method and print the count
        ///  </summary>
        static void Main(string[] args)
        {
            string userSentance = string.Empty;
            int totalWords = 0;
            Console.WriteLine("Enter the your sentance");
            userSentance = Console.ReadLine();
            //calling Extension Method WordCount
            totalWords = userSentance.WordCount();
            Console.WriteLine("Total number of words is :" + totalWords);
            Console.ReadKey();
        }
    }
    /// <summary>
    ///  extension method to count the number of words in a sentence
    ///  </summary>
    public static class Extension
    {
        public static int WordCount(this string str)
        {
            string[] userString = str.Split(new char[] { ' ', '.', '?' },
                                        StringSplitOptions.RemoveEmptyEntries);
            int wordCount = userString.Length;
            return wordCount;
        }
       
        
    }

}
