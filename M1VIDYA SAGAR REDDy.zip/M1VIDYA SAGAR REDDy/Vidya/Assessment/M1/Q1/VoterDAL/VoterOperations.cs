﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using VoterEntity;
using VoterExceptions;

namespace VoterDAL
{
    /// <summary>
    /// Employee ID : 161271
    /// Employee Name : Nikita Tiwari
    /// Description : This class will provide CRUD operations for Voter
    /// Date of Modification : 8th Oct 2018
    /// </summary>
    public class VoterOperations
    {
        static List<Voter> voterList = new List<Voter>();

        //Method to add new voter
        public static bool AddVoter(Voter voter)
        {
            bool isAdded = false;

            try
            {
                //Adding voter in the list
                voterList.Add(voter);
                isAdded = true;
            }
            catch (VoterException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return isAdded;
        }
        //Method to search voter information
        public static Voter SearchVoter(string voterID)
        {
            Voter voter = null;

            try
            {
                //Searching voter
                voter = voterList.Find(e => e.VoterID == voterID);
            }
            catch (VoterException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return voter;
        }
        //Method to display all voter
        public static List<Voter> DisplayVoters()
        {
            return voterList;
        }
        //Method to Serialize voter Data
        public static bool SerializeEmployee()
        {
            bool isSerialized = false;

            try
            {
                //Creating object of stream
                FileStream fs = new FileStream("Voter.txt", FileMode.Create, FileAccess.Write);
                //Creating BinaryFormatter object
                BinaryFormatter bin = new BinaryFormatter();
                //Serializing voter data in stream
                bin.Serialize(fs, voterList);
                fs.Close();
                isSerialized = true;
            }
            catch (VoterException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return isSerialized;
        }
        //Method to deserialize voter details
        public static List<Voter> DeserializeVoter()
        {
            List<Voter> voterDesList = null;

            try
            {
                //Creating object of stream
                FileStream fs = new FileStream("Voter.txt", FileMode.Open, FileAccess.Read);
                //Creating BinaryFormatter object
                BinaryFormatter bin = new BinaryFormatter();
                //Deserializing voter data from stream
                voterDesList = (List<Voter>)bin.Deserialize(fs);
                fs.Close();
            }
            catch (VoterException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return voterDesList;
        }

        public static bool AddVoter(object voter)
        {
            throw new NotImplementedException();
        }
    }
}
