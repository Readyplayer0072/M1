﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VoterEntity
{
    /// <summary>
    /// Employee ID : 161271
    /// Employee Name : Nikita Tiwari
    /// Description : This is an Entity Class for Voter
    /// Date of Modification : 8th Oct 2018
    /// </summary>
    [Serializable]
    public class Voter
    {
        //Get or Set Voter ID
        public string VoterID { get; set; }

        //Get or Set Voter Name
        public string VoterName { get; set; }

        //Get or Set Ward
        public string Ward { get; set; }

        //Get or Set City
        public string City { get; set; }

        //Get or Set State
        public string State { get; set; }

        //Get or Set Party to Vote For
        public string Party { get; set; }

        //Get or Set Reason to Vote
        public string ReasonToVote { get; set; }

    }
}
