﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using VoterDAL;
using VoterEntity;
using VoterExceptions;

namespace VoterBLL
{
    /// <summary>
    /// Employee ID : 161271
    /// Employee Name : Nikita Tiwari
    /// Description : This class will have business logic for Voter
    /// Date of Modification : 8th Oct 2018
    /// </summary>
    public class VoterValidations
    {
        public static bool ValidateVoter(Voter voter)
        {
            bool isValidated = true;

            StringBuilder message = new StringBuilder();
            try
            {
                //Checking voter id that it should be 7 characters
                if (voter.VoterID == string.Empty)
                {
                    message.Append("Voter ID should be provided\n");
                    isValidated = false;
                }
                else if (!Regex.IsMatch(voter.VoterID, "[A-Z][A-Z][1-9]{6,}"))
                {
                    message.Append("Voter ID should start with two Capital Alphabets followed by 5 digits, it should have 7 characters\n");
                    isValidated = false;
                }

                //Checking voter name
                if (voter.VoterName == string.Empty)
                {
                    message.Append("Voter Name should be provided\n");
                    isValidated = false;
                }
                else if (!Regex.IsMatch(voter.VoterName, "[A-Z][a-z]{3,7}"))
                {
                    message.Append("Voter Name should start with Capital Alphabet, it should have minimum 4 characters and Maximum 8 \n");
                    isValidated = false;
                }

                //Checking Ward
                if (voter.Ward.ToLower() != "North" && voter.Ward.ToLower() != "South" && voter.Ward.ToLower() != "East" && voter.Ward.ToLower() != "West")
                {
                    message.Append("Ward should be either North or South or East or West\n");
                    isValidated = false;
                }

                //Checking City
                if (voter.City.ToLower() != "Bangalore" && voter.City.ToLower() != "Mysore" && voter.City.ToLower() != "Hubli")
                {
                    message.Append("City should be either Bangalore or Mysore or Hubli\n");
                    isValidated = false;
                }

                //Checking PartyToVoteFor
                if (voter.Party.ToLower() != "BJP" && voter.Party.ToLower() != "Congress" && voter.Party.ToLower() != "JD")
                {
                    message.Append("Party should be either BJP or Congress or JD\n");
                    isValidated = false;
                }

                //Checking for ReasonToVoteFor
                if (voter.ReasonToVote == string.Empty)
                {
                    message.Append("Reason to vote for should be provided\n");
                    isValidated = false;
                }
                else if (!Regex.IsMatch(voter.ReasonToVote, "[a-z]{199,}"))
                {
                    message.Append("Reason should have Maximum 200 characters \n");
                    isValidated = false;
                }
            }
            catch (VoterException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return isValidated;
        }
        //Method to add new voter
        public static bool AddVoter(Voter voter)
        {
            bool isAdded = false;

            try
            {
                
                if (ValidateVoter(voter))
                {
                    
                    isAdded = VoterOperations.AddVoter(voter);
                }
                else
                    throw new VoterException("Please provide valid voter details");
            }
            catch (VoterException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return isAdded;
        }
        //Method to search voter
        public static Voter SearchVoter(string voterID)
        {
            Voter voter = null;

            try
            {
                
                voter = VoterOperations.SearchVoter(voterID);
            }
            catch (VoterException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return voter;
        }
        //Method to display all voters
        public static List<Voter> DisplayVoter()
        {
            List<Voter> voterList = null;

            try
            {
               
                voterList = VoterOperations.DisplayVoters();
            }
            catch (VoterException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return voterList;
        }
        //Method to serialize voter details
        public static bool SerializeVoter()
        {
            bool isSerialized = false;

            try
            {
               
                isSerialized = VoterValidations.SerializeVoter();
            }
            catch (VoterException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return isSerialized;
        }
        //Method to Deserialize Voter
        public static List<Voter> DeserializeVoter()
        {
            List<Voter> voterList = null;

            try
            {
               
                voterList = VoterOperations.DeserializeVoter();
            }
            catch (VoterException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return voterList;
        }



    }

    
}
