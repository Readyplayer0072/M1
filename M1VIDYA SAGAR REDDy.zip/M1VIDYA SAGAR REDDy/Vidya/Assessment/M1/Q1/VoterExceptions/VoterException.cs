﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VoterExceptions
{
    /// <summary>
    /// Employee ID : 161271
    /// Employee Name : Nikita Tiwari
    /// Descrition : This is an  exception class for an VoterData
    /// Date of Modification : 4th Oct 2018
    /// </summary>
    public class VoterException :  ApplicationException
    {
        //Default Constructor
        public VoterException()
            : base()
        { }

        //Parameterized constructor with message parameter
        public VoterException(string message)
            : base(message)
        { }
    }
}
