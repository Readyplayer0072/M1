﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VoterBLL;
using VoterEntity;
using VoterExceptions;

namespace VoterData
{
    class Program
    {
        public static void AddVoter()
        {
            try
            {
                Voter voter = new Voter();
                Console.Write("Enter Voter ID : ");
                voter.VoterID = Console.ReadLine();

                Console.Write("Enter Voter Name : ");
                voter.VoterName = Console.ReadLine();

                Console.Write("Enter Ward Name : ");
                voter.Ward = Console.ReadLine();

                Console.Write("Enter City Name : ");
                voter.City = Console.ReadLine();

                Console.Write("Enter State Name : ");
                voter.State = Console.ReadLine();

                Console.Write("Enter Party To Vote For : ");
                voter.Party = Console.ReadLine();

                Console.Write("Enter Reason To Vote : ");
                voter.ReasonToVote = Console.ReadLine();

                bool isAdded = VoterValidations.AddVoter(voter);

                if (isAdded)
                {
                    Console.WriteLine("Voter details added successfully");
                }
                else
                    throw new VoterException("Employee details not added");
            }
            catch (VoterException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
            public static void SearchVoter()
            {
                try
                {
                    string voterID;

                    Console.Write("Enter Voter ID for Search : ");
                    voterID = (Console.ReadLine());

                   Voter voter = VoterValidations.SearchVoter(voterID);

                    if (voter != null)
                    {
                        Console.WriteLine("Voter ID : " + voter.VoterID);
                        Console.WriteLine("Voter Name : " + voter.VoterName);
                        Console.WriteLine("Ward  : " + voter.Ward);
                        Console.WriteLine("City : " + voter.City);
                        Console.WriteLine("State : " + voter.State);
                        Console.WriteLine("Party to Vote For : " + voter.Party);
                        Console.WriteLine("Reason To Vote : " + voter.ReasonToVote);
                    }
                    else
                        throw new VoterException("Voter " + voterID + " not found");
                }
                catch (VoterException ex)
                {
                    Console.WriteLine(ex.Message);
                }
                catch (SystemException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        public static void DisplayVoter()
        {
            try
            {
                List<Voter> voterList = VoterValidations.DisplayVoter();

                if (voterList != null || voterList.Count > 0)
                {
                    Console.WriteLine("***********************************************************************************************************************");
                    Console.WriteLine("Voter ID     Voter Name    Ward       City       State      Party     ReasonToVoteFor");
                    Console.WriteLine("***********************************************************************************************************************");
                    foreach (Voter voter in voterList)
                    {
                        Console.WriteLine(voter.VoterID + "\t" + voter.VoterName + "\t" + voter.Ward + "\t" + voter.City + "\t" + voter.State + "\t" + voter.Party + "\t" + voter.ReasonToVote);
                    }
                    Console.WriteLine("***********************************************************************************************************************");
                }
                else
                    throw new VoterException("Voter Details not available");
            }
            catch (VoterException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void SerializeVoter()
        {
            try
            {
                bool isSerialized = VoterValidations.SerializeVoter();

                if (isSerialized)
                    Console.WriteLine("Voter Data is Serialized");
                else
                    throw new VoterException("Voter Data is not Serialized");
            }
            catch (VoterException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void DeserializeVoter()
        {
            try
            {
                List<Voter> voterList = VoterValidations.DeserializeVoter();

                if (voterList != null || voterList.Count > 0)
                {
                    Console.WriteLine("***********************************************************************************************************************");
                    Console.WriteLine("Voter ID     Voter Name    Ward       City       State      Party     ReasonToVoteFor");
                    Console.WriteLine("***********************************************************************************************************************");
                    foreach (Voter voter in voterList)
                    {
                        Console.WriteLine(voter.VoterID + "\t" + voter.VoterName + "\t" + voter.Ward + "\t" + voter.City + "\t" + voter.State + "\t" + voter.Party + "\t" + voter.ReasonToVote);
                    }
                    Console.WriteLine("***********************************************************************************************************************");
                }
                else
                    throw new VoterException("Voter Details not deserialized");
            }
            catch (VoterException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void PrintMenu()
        {
            Console.WriteLine("----------------------------");
            Console.WriteLine("1. Add Voter");
            Console.WriteLine("2. Search Voter");
            Console.WriteLine("3. Display Voter");
            Console.WriteLine("4. Serialize Voter");
            Console.WriteLine("5. Deseialize Voter");
            Console.WriteLine("6. Exit");
            Console.WriteLine("----------------------------");
        }

        static void Main(string[] args)
        {
            try
            {
                int choice;

                do
                {
                    PrintMenu();
                    Console.Write("Enter your choice : ");
                    choice = Convert.ToInt32(Console.ReadLine());

                    switch (choice)
                    {
                        case 1:
                            AddVoter();
                            break;
                        
                        
                        case 2:
                            SearchVoter();
                            break;
                        case 3:
                            DisplayVoter();
                            break;
                        case 4:
                            SerializeVoter();
                            break;
                        case 5:
                            DeserializeVoter();
                            break;
                        case 6:
                            Environment.Exit(0);
                            break;
                        default:
                            Console.Write("Invalid Choice");
                            break;
                    }
                } while (choice != 6);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }
    }
}
