﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FareCalculator
{
    class FareCalculators
    {/// <summary>
    /// FareCalculator class to calculate the total fare according to the user input 
    /// Author: Rohit Kumar Chandel
    /// DOC: 8 October 2018
    /// </summary>
    /// <param name="choice"></param>
    /// <param name="kilometer"></param>
    /// <returns></returns>
        public static double Calculate(int choice, double kilometer) => choice * kilometer;//Calculate Method(Expression bodied) 

        static void Main(string[] args)
        {

            int choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter Your Choice");
                bool chkChoice;
                chkChoice = int.TryParse(Console.ReadLine(), out choice);
                if (!chkChoice) { Console.WriteLine("Invalid Input"); }
                
                switch (choice)
                {
                    case 1:
                        Console.WriteLine("Enter 1 for Mini or 2 for Sedan");//Taking user input for their choice of vehicle
                        int VehicleType = int.Parse(Console.ReadLine());
                        if (VehicleType == 1 || VehicleType == 2)
                        {
                            if (VehicleType == 1)
                            {
                                Console.WriteLine("Enter KiloMeters Driven");//Taking user input of Kilometers driven
                                double KilometersDriven = double.Parse(Console.ReadLine());
                                Console.WriteLine($"Total Kilometers:{KilometersDriven}\nVehicle Type: Sedan");
                                Console.WriteLine($"Total Fare Ammount:6*{KilometersDriven}=" + Calculate(6, KilometersDriven));
                            }
                            if (VehicleType == 2)
                            {
                                Console.WriteLine("Enter KiloMeters Driven");
                                double KilometersDriven = double.Parse(Console.ReadLine());
                                Console.WriteLine($"Total Kilometers:{KilometersDriven}\n Vehicle Type: Sedan");
                                Console.WriteLine($"Total Fare Ammount:12*{KilometersDriven}=" + Calculate(12, KilometersDriven));
                            }
                        }
                        else { Console.WriteLine("Invalid Input"); }
                        break;
                    case 2: Console.WriteLine("THANK YOU FOR USING FARE CALCULATOR"); break;
                    default: Console.WriteLine("Invalid Input"); break;

                }

                if (choice == 2)
                    break;
            } while (choice != 0);
        }

        private static void PrintMenu()
        {
            Console.WriteLine("************************************");
            Console.WriteLine("Enter 1 to Calculate Fare or 2 to Exit");
            Console.WriteLine("************************************");

        }
    }
}
