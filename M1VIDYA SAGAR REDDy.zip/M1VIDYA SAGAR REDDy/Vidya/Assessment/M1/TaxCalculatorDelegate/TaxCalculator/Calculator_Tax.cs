﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
///  Tax calculation using Delegates
///  author:Rohit Kumar Chandel
///  Date :27/10/2018
/// </summary>


//Delegate declaration
delegate double CalculateTax(double Salary, double percentage);

namespace TaxCalculator
{
    class Calculator_Tax
    {
        public double Salary;
        public double TaxPercentage;

        public static double Tax(double Salary, double Percentage) => Salary * 0.01 * Percentage;

        static void Main(string[] args)
        {
            Calculator_Tax C1 = new Calculator_Tax();
            Console.WriteLine("Enter Gross Salary amount: ");
            C1.Salary = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter Tax percentage: ");
            C1.TaxPercentage = Convert.ToDouble(Console.ReadLine());

            CalculateTax TaxCalculator = new CalculateTax(Tax);
            Console.WriteLine("Tax amount is: " + Tax(C1.Salary, C1.TaxPercentage));

        }
    }
}
