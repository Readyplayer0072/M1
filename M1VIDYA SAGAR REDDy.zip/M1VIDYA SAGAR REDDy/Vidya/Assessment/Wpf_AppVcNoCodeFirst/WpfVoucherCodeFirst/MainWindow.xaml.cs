﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Wpf_AppVcNoCodeFirst
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// Author: Rohit kumar Chandel
    /// Date:22/10/2018
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        ParticipantDbContext db1 = new ParticipantDbContext();
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            bingdatagrid();


        }


        void bingdatagrid()
        {
            var data = (from temp in db1.Vouchers
                        where temp.ParticipantName == Name.Text
                        select temp).ToList();

        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Participant Obj = new Participant();
            try
            {
                Obj.VoucherNumber = VcNumber.Text;
                Obj.ParticipantName = Name.Text;
                Obj.Technology = Technology.Text;
                Obj.CertificationCode = Certcode.Text;
                Obj.CertificationName = Certname.Text;
                Obj.CertificationDate = Convert.ToDateTime(Certdate.Text);
                db1.SaveChanges();
                bingdatagrid();
            }
            catch (DbEntityValidationException dbError)
            {
                foreach (DbEntityValidationResult entityErr in dbError.EntityValidationErrors)
                {
                    foreach (DbValidationError error in entityErr.ValidationErrors)
                    {
                        //   MessageBox.Show("Error Property Name " + error.PropertyName + " Error : " + error.ErrorMessage);
                        MessageBox.Show(error.ErrorMessage);
                    }
                }
            }
        }
    }
}
    

