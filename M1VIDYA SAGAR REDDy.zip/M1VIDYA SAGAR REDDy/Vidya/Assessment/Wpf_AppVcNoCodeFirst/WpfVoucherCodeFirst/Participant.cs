﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity.Validation;
using System.Data.Entity.Infrastructure;

namespace Wpf_AppVcNoCodeFirst
{
    class Participant
    {
        //The attributes for table and conditions for validation
        [Key]
        public string VoucherNumber { get; set; }
        [Required(ErrorMessage = "Participant Name is Required")]
        [MinLength(3, ErrorMessage = "Min characters 3 are needed")]
        [MaxLength(40, ErrorMessage = "Max 40 characteres are allowed")]
        public string ParticipantName { get; set; }
        [Required(ErrorMessage = "technology is Required")]
        [Range(1, 30, ErrorMessage = "technology Range is 1-30")]
        public string Technology { get; set; }
        [Required(ErrorMessage = "Code is Required")]
        public string CertificationCode { get; set; }
        [Required]
        public string CertificationName { get; set; }
        [DataType(DataType.Date)]
        [Required]
        public DateTime CertificationDate { get; set; }
        
    }
    class ParticipantDbContext : DbContext
    {
        public DbSet<Participant> Vouchers { get; set; }

        protected override DbEntityValidationResult ValidateEntity(DbEntityEntry entityEntry, System.Collections.Generic.IDictionary<object, object> items)
        {
            
            return base.ValidateEntity(entityEntry, items);
        }

    }
}
