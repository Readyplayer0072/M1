﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace serializationanddeserialization
{
    [Serializable]
    class employee
    {
        public int empid { get; set; }
        public string empname { get; set; }
        public double empsalary { get; set; }

    }
}
