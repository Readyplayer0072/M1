﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace serializationanddeserialization
{
    [Serializable]
    class employee1

    {
        static void Main(string[] args)
        {
            List<employee> emp = new List<employee>();
            for (int i = 0; i < 5; i++)

            {
            
                Console.WriteLine("employee Id");
                int empid = int.Parse(Console.ReadLine());

                Console.WriteLine("employee name");
                string empname = Console.ReadLine();

                Console.WriteLine("employee salary");
                double empsalary = double.Parse(Console.ReadLine());

                employee emp1 = new employee()
                {
                    empid = empid,
                    empname = empname,
                    empsalary = empsalary

                };
                emp.Add(emp1);
                Console.WriteLine("employee added sucessfully");
            }
                Console.WriteLine("all employees are added");
            FileStream filestream = new FileStream("employeedetails.txt", FileMode.Create);
            BinaryFormatter binaryFormatter = new BinaryFormatter();
            binaryFormatter.Serialize(filestream, emp);
            filestream.Close();

            Console.WriteLine("serialization completed sucessfully");

             FileStream filestream1 = new FileStream("employeedetails.txt", FileMode.Open);
            BinaryFormatter binaryFormatter1 = new BinaryFormatter();
            List<employee> retrivedemployess = new List<employee>();
            filestream.Close();
            Console.WriteLine("deserialization completed sucessfully");
            foreach (employee employee in retrivedemployess )
            

            
            {
                Console.WriteLine("empid:{0} \t,empname:{1} \t,empsalary:{2} \t", employee.empid, employee.empname,
                    employee.empsalary);
            }

        }


        
        
    }
}

