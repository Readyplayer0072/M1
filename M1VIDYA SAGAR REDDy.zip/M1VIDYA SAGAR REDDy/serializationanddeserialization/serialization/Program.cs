﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;


namespace serializationanddeserialization
{
    class Program
    {
        static void Main(string[] args)
        {
            employee employee1 = new employee()
            {
                empid = 101,
                empname = "sagar",
                empsalary = 20000
            };
            FileStream filestream = new FileStream("employeedata.txt", FileMode.Create);
            BinaryFormatter binaryFormatter = new BinaryFormatter();
            binaryFormatter.Serialize(filestream, employee1);
            filestream.Close();
            Console.WriteLine("serialization completed sucessfully");

            FileStream filestream1 = new FileStream("employeedata.txt", FileMode.Open);
            BinaryFormatter binaryFormatter1 = new BinaryFormatter();
            employee employee2 = (employee)binaryFormatter1.Deserialize(filestream1);
            filestream.Close();
            Console.WriteLine("deserialization completed sucessfully");
            Console.WriteLine("empid:{0} \t,empname:{1} \t,empsalary:{2} \t", employee2.empid, employee2.empname,
                employee2.empsalary);

        }
    }
}
