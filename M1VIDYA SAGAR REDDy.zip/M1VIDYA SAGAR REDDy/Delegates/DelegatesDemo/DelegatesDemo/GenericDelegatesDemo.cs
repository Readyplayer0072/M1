﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesDemo
{
    public delegate T MyDelegate2<T>(T X, T Y);  
    class GenericDelegatesDemo
    {
        static int sum(int X, int Y)
        {
            return X + Y;
        }
        static double substract(double X, double Y)
        {
            return X - Y;
        }
        static double multiply(double X, double Y)
        {
            return X * Y;
        }
        static void Main(string[] args)
        {
            MyDelegate2<int> myDelegate21 = new MyDelegate2<int>(sum);
            Console.WriteLine(myDelegate21(10, 20));
            MyDelegate2<double> myDelegate22 = new MyDelegate2<double>(substract);
            Console.WriteLine(myDelegate22(10, 70));
            MyDelegate2<double> myDelegate23 = new MyDelegate2<double>(multiply);
            Console.WriteLine(myDelegate23(10, 200));
        }
    }
}
