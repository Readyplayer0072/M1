﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesDemo
{
    public delegate int Mydelegate3(int X, int Y);
    class AnonymusMethodandLambda
    {
      
        static void Main(string[] args)
        {
            //Mydelegate3 mydelegate3 = delegate (int X, int Y)
            //{
            //    return X + Y;
            //};
            Mydelegate3 mydelegate3 =  ( X, Y) => 
            {
                return X + Y;
            };
            Console.WriteLine(mydelegate3(10, 20));
        }
    }
}
