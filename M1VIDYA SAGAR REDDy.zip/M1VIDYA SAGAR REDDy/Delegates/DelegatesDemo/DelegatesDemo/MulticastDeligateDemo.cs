﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesDemo
{
    public delegate void MyDelegate1(double X, double Y);
    class MulticastDeligateDemo
    {
        static void sum(double X, double Y)
        {
            Console.WriteLine("sum="+(X+Y));
        }
        static void substract(double X, double Y)
        {
            Console.WriteLine("substract=" + (X - Y));
        }
        static void multiply(double X, double Y)
        {
            Console.WriteLine("product=" + (X * Y));
        }
        static void divide(double X, double Y)
        {
            Console.WriteLine("quoitent=" + (X / Y));
        }
        static void Main(string[] args)
        {
            MyDelegate1 myDelegate1 = new MyDelegate1(sum);
            myDelegate1 += substract;
            myDelegate1 += multiply;
            myDelegate1 += divide;
            myDelegate1(12.30, 23.90);

        }
    }
}
