﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace ReflectionDemo
{
    class program1
    {
        static void Main(string[] args)
        {
            Type empType = typeof(Employee);
            MethodInfo[] methods = empType.GetMethods();
            foreach (MethodInfo method in methods)
            {
                Console.WriteLine(method.Name);
            }
            Console.WriteLine();
        }
    }
}
