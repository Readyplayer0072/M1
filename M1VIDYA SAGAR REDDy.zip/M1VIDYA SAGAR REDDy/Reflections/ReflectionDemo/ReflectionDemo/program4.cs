﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ReflectionDemo
{
    class program4
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Select Class:");
            string ClassName = Console.ReadLine();

            Assembly assembly = Assembly.GetExecutingAssembly();

            string NamespaceName = assembly.FullName;
            string[] Myarray = NamespaceName.Split(',');
            string OnlyNamespaceName = Myarray[0];

            Type type = assembly.GetType(OnlyNamespaceName + "." + ClassName);

            Console.Write("Select Method:");
            string MethodName = Console.ReadLine();
            MethodInfo method = type.GetMethod(MethodName);

            object obj = assembly.CreateInstance(OnlyNamespaceName + "."+ClassName);

            PropertyInfo[] propertyInfos = type.GetProperties();
            propertyInfos[0].SetValue(obj, 10);
            propertyInfos[1].SetValue(obj, 10);

            int Result =(int) method.Invoke(obj, null);
            Console.WriteLine(Result);

        }
    }
}
