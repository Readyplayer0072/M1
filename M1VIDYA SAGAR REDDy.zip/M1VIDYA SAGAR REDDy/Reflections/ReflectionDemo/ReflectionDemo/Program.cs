﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ReflectionDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Assembly assembly = Assembly.LoadFrom(@"C:\Users\lungidance\Desktop\visual studio\SMSApp\SMSDAL\bin\Debug\SMSDAL.dll");

            Type[] types = assembly.GetTypes();
            foreach (Type type in types)
            {
                Console.WriteLine(type.Name);
                Console.WriteLine(type.Namespace);
            }
        }
    }
}
