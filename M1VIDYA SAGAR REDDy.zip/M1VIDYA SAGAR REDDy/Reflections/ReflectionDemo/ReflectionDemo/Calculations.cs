﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReflectionDemo
{
    class Calculations
    {
        public int Number1{ get; set; }
        public int Number2 { get; set; }

        public int  AddTwonumbers()
        {
            return Number1 + Number2;
        }

    }
}
