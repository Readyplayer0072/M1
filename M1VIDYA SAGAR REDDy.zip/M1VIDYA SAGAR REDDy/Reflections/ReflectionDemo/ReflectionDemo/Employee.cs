﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReflectionDemo
{
    class Employee
    {
        public int Id;
        public string  Name;
        public float Salary;

        public Employee() { }
        public Employee(int Id,string name,float Salary) { }

        public void SetEmployee() { }
        public void GetEmployee() { }

        public int TotalExperience { get; set; }
        public int currentExperience { get; set; }
    }
}
