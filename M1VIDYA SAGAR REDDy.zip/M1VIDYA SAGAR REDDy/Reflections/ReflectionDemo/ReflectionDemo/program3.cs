﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ReflectionDemo
{
    class program3
    {
        static void Main(string[] args)
        {
            Type empType = typeof(Employee);
            PropertyInfo[] properties = empType.GetProperties();
            foreach (PropertyInfo property in properties)
            {
                Console.WriteLine(property.Name);
            }
            Console.WriteLine();
        }
    }
}
