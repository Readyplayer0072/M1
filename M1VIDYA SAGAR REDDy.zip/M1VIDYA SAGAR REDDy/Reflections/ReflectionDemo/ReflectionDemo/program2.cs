﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
namespace ReflectionDemo
{
    class program2
    {
        static void Main(string[] args)
        {
            Type empType = typeof(Employee);

            ConstructorInfo[] constructors= empType.GetConstructors();
            foreach (ConstructorInfo constructor in constructors)
            {
                Console.WriteLine(constructor.Name);
            }
            Console.WriteLine();
        }
    }
}
