﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace FareCalculator
{/// <summary>
        ///Using Reflection to Show details of Methods And Constructors 
/// Author:Aditya Joshi
/// DOC: 8 October 2018
/// </summary>
    class ReflectionFareCalculator
    {
        static void Main(string[] args)
        {
            Type ReflectionFare = typeof(FareCalculators);
            MethodInfo[] methods = ReflectionFare.GetMethods();//Getting the info of methods 

            Console.WriteLine("List of Methods");
            foreach(MethodInfo methodInfo in methods)
                Console.WriteLine(methodInfo.Name);//Displaying method names
            ConstructorInfo[] constructs = ReflectionFare.GetConstructors();//Getting the info of constructors 
            Console.WriteLine("List of Constructors");
            foreach (ConstructorInfo constructorInfo in constructs)
                Console.WriteLine(constructorInfo.Name);// Displaying Constructor names

        }


    }
}
